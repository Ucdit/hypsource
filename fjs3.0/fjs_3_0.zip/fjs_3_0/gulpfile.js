// gulp 是一个流式打包系统(streaming build system)，如果以前没用过，请看 https://www.youtube.com/watch?v=dwSLFai8ovQ
// live reload 让你在修改源文件之后，不用手工刷新 chrome 浏览器就能看到修改后的结果，教程：https://www.youtube.com/watch?v=r5fvdIa0ETk
// 在命令行上运行 NODE_ENV=stage gulp watch 单独打开 live reload，直接运行 NODE_ENV=stage gulp 命令则自动启动 express 服务器并打开 live reload。

var gulp = require('gulp'),
    livereload = require('gulp-livereload');

gulp.task('app', function () {
    var app = require('./app.js');
});

gulp.task('watch', function () {    // 这里的watch，是自定义的，写成live或者别的也行
    var server = livereload();
    livereload.listen();

    // app/**/*.*的意思是 app文件夹下的 任何文件夹 的 任何文件
    gulp.watch('views/**/*.*', function (file) {
        server.changed(file.path);
    });

    gulp.watch('public/**/*.*', function (file) {
        server.changed(file.path);
    });
});

gulp.task('default', ['app', 'watch'], function() {
    console.log("server started, liveloading");
});
