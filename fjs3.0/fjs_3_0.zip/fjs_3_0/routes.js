var fs = require('fs');
module.exports = function(app){
    app.get('/cross_domain_demo', function(req, res, next){
        res.render('cross_domain_demo.ejs', {});
    });

    app.get('/cross_domain_demo2', function(req, res, next){
        res.render('cross_domain_demo2.ejs', {});
    });

    app.get('/cross_domain_demo3', function(req, res, next){
        res.render('cross_domain_demo3.ejs', {});
    });

    app.get('/upload_demo', function(req, res, next){
        res.render('upload_demo.ejs', {});
    });
    // 稍后注册百度统计
    app.get('/statistic_later_sub', function(req, res, next){
        res.render('statistic_later_sub.ejs', {});
    });
    // 注册发布百度统计
    app.get('/statistic_regandsub', function(req, res, next){
        res.render('statistic_regandsub.ejs', {});
    });

	// 首页
    app.get('/', function(req, res, next){
        res.render('index.ejs', {});
    });

    app.get('/house_list', function(req, res, next){
        res.redirect(301, '/')
    });

    app.get('/fund_list', function(req, res, next){
        res.redirect(301, '/')
    });

    app.get('/fund_map', function(req, res, next){
        res.redirect(301, '/')
    });

    app.get('/newBoy', function(req, res, next){
        res.redirect(301, '/')
    });

    app.get('/zixun', function(req, res, next){
        res.redirect(301, '/zixun')
    });

    app.get('/robots.txt', function(req, res, next){
        fs.exists(__dirname + '/robots.txt', function( exists ){
           if (exists) {
                fs.readFile(__dirname + "/robots.txt","utf-8", function(err, data){
                   res.send(data);
                });
           }
        });
    });

    // 关于我们
    app.get('/about', function(req, res, next){
        res.render('about.ejs', {});
    });

    // 服务条款
    app.get('/terms', function(req, res, next){
        res.render('terms.ejs', {});
    });

    // 联系我们
    app.get('/contact_us', function(req, res, next){
        res.render('contact_us.ejs', {});
    });

    // 新闻详情页
    app.get('/news_list', function(req, res, next){
        res.render('news_list.ejs', {});
    });

    // 联系我们
    app.get('/news', function(req, res, next){
        res.render('news.ejs', {});
    });

    // 注册页面
    app.get('/register', function(req, res, next){
        res.render('register.ejs', {});
    });
    // 产品详情页
    app.get('/product_detail', function(req, res, next){
        res.render('product_detail.ejs', {});
    });

    // 房产详情页
    app.get('/realestate_detail', function(req, res, next){
        res.render('realestate_detail.ejs', {});
    });
    
    // 登录页面
    app.get('/login', function(req, res, next){
        res.render('login.ejs', {});
    });

    // 房产抵押贷
    app.get('/realestate_mortgage', function(req, res, next){
        res.render('realestate_mortgage.ejs', {});
    });

    // 房产抵押贷 推广
    app.get('/realestate_fcdyd', function(req, res, next){
        res.render('realestate_fcdyd.ejs', {});
    });

    // 以房理财
    app.get('/realestate_financing', function(req, res, next){
        res.render('realestate_financing.ejs', {});
    });

    // 以房买房
    app.get('/realestate_buy', function(req, res, next){
        res.render('realestate_buy.ejs', {});
    });

    // 以房移民
    app.get('/realestate_immigrant', function(req, res, next){
        res.render('realestate_immigrant.ejs', {});
    });

    // 以房教育
    app.get('/realestate_educate', function(req, res, next){
        res.render('realestate_educate.ejs', {});
    });

    // 房金地图
    app.get('/realestate_map', function(req, res, next){
        res.render('realestate_map.ejs', {});
    });

    //搜索匹配
    app.get('/search', function(req, res, next){
        res.render('search.ejs', {});
    });


    //信贷经理个人中心
    app.get('/uc/manager', function(req, res, next){
        res.render('uc_manager.ejs', {});
    });

    //房产房个人中心 个人信息页
    app.get('/uc/realestate/info', function(req, res, next){
        res.render('uc_realestate_info.ejs', {});
    });

    //信贷经理个人中心 个人信息页
    app.get('/uc/manager/info', function(req, res, next){
        res.render('uc_manager_info.ejs', {});
    });

    //信贷经理个人中心 个人信息页
    app.get('/uc/manager/info', function(req, res, next){
        res.render('uc_manager_info.ejs', {});
    });

    //信贷经理个人中心 认证信息
    app.get('/uc/manager/auth', function(req, res, next){
        res.render('uc_manager_auth.ejs', {});
    });

    //信贷经理个人中心 我的机构产品
    app.get('/uc/manager/product', function(req, res, next){
        res.render('uc_manager_product.ejs', {});
    });

    //信贷经理个人中心 添加机构产品
    app.get('/uc/manager/product/add', function(req, res, next){
        res.render('uc_manager_product_add.ejs', {});
    });

    //信贷经理个人中心 合作机构产品
    app.get('/uc/manager/agentproduct', function(req, res, next){
        res.render('uc_manager_agentproduct.ejs', {});
    });

    //信贷经理个人中心 案例管理
    app.get('/uc/manager/case', function(req, res, next){
        res.render('uc_manager_case.ejs', {});
    });

    //信贷经理个人中心 申请管理
    app.get('/uc/manager/apply', function(req, res, next){
        res.render('uc_manager_apply.ejs', {});
    });

    //信贷经理个人中心 修改密码
    app.get('/uc/manager/set_password', function(req, res, next){
        res.render('uc_manager_password.ejs', {});
    });
    
    //房产方个人中心
    app.get('/uc/realestate', function(req, res, next){
        res.render('uc_realestate.ejs', {});
    });

    //房产方设置密码
    app.get('/uc/realestate/set_password', function(req, res, next){
        res.render('uc_realestate_set_passwd.ejs', {});
    });

    //房产方已发布的需求
    app.get('/uc/realestate/my_need', function(req, res, next){
        res.render('uc_realestate_my_need.ejs', {});
    });

    /*后台页面路由*/
    app.get('/fjs', function(req, res, next){
        res.render('admin/index.ejs', {});
    });

    app.get('/fjs/login', function(req, res, next){
        res.render('admin/login.ejs', {});
    });

    app.get('/fjs/org_list', function(req, res, next){
        res.render('admin/org_list.ejs', {});
    });

    app.get('/fjs/org_add', function(req, res, next){
        res.render('admin/org_add.ejs', {});
    });

    app.get('/fjs/edit_org', function(req, res, next){
        res.render('admin/edit_org.ejs', {});
    });

    app.get('/fjs/manager_list', function(req, res, next){
        res.render('admin/manager_list.ejs', {});
    });

    app.get('/fjs/manager_edit', function(req, res, next){
        res.render('admin/manager_edit.ejs', {});
    });

    app.get('/fjs/manager', function(req, res, next){
        res.render('admin/manager_list.ejs', {});
    });

    app.get('/fjs/user_list', function(req, res, next){
        res.render('admin/user_list.ejs', {});
    });

    app.get('/fjs/need_list', function(req, res, next){
        res.render('admin/need_list.ejs', {});
    });

    app.get('/fjs/edit_need', function(req, res, next){
        res.render('admin/edit_need.ejs', {});
    });

    app.get('/fjs/api_log', function(req, res, next){
        res.render('admin/api_log.ejs', {});
    });

    app.get('/fjs/jz_sms_log', function(req, res, next){
        res.render('admin/jz_sms_log.ejs', {});
    });

    // app.get('/fjs/add_org', function(req, res, next){
    //     res.render('admin/add_org.ejs', {});
    // });

    app.get('/fjs/article_add', function(req, res){
        res.render('admin/article_add.ejs', {});
    });

    app.get('/fjs/article_list', function(req, res){
        res.render('admin/article_list.ejs', {});
    });
    
    app.get('/fjs/article_edit', function(req, res){
        res.render('admin/article_edit.ejs', {});
    });

    app.get('/fjs/add_manager_to_org', function(req, res){
        res.render('admin/add_manager_to_org.ejs', {});
    });

    app.get('/fjs/case_list', function(req, res){
        res.render('admin/manager_case_list.ejs', {});
    });

    app.get('/fjs/add_case', function(req, res){
        res.render('admin/manager_case_add.ejs', {});
    });

    app.get('/fjs/apply_list', function(req, res){
        res.render('admin/apply_list.ejs', {});
    });
};
 
