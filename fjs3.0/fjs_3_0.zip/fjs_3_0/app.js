var express = require('express');
var path = require('path');
var favicon = require('static-favicon');
var morgan = require('morgan');
var fs = require('fs');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var config = require('./common/config.js');
var forward = require('./common/forward.js');
var useragent = require('express-useragent');

var app = express();

app.set('trust proxy', true);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(favicon('public/favicon.ico'));
 

//网站访问log
var accessLogStream = fs.createWriteStream(__dirname + '/log/access.log'
        , {flags: 'a'});
if(app.get('env') === 'development'){
    app.use(morgan('dev', {stream: accessLogStream}));
}else{
    app.use(morgan('combined', {stream: accessLogStream}));
}

//把对fangjinsuo.com的请求redirect到www.fangjinsuo.com
if(process.env.NODE_ENV==='production'){
    app.get('/*', function (req, res, next) {  
        var haswww = req.headers.host.match(/^www\./);
        var url = ['http://www.', req.headers.host, req.url].join('');

        if(haswww){
            next()
        }else{
            res.redirect(301, url);  
        }
    });
}

app.use(forward(/\/fjsapi\/(.*)/, config.apiUrl))

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

app.use(cookieParser());

app.disable('x-powered-by');

app.use(express.static(path.join(__dirname, 'public')));

app.use(function(req, res, next){
    var source = req.get('user-agent');

    if(!source) return false;

    var ua = useragent.parse(source);

    //console.log(ua)
    // if(ua.source.indexOf('Nexus 7') > -1){
    //     return false;
    // }

    if(ua.isMobile && !ua.isiPad && !ua.isAndroidTablet){
        res.redirect('http://m.fangjinsuo.com/');
    }else{
        next();
    }
});

require('./routes.js')(app);

/// catch 404 and forward to error handler
app.use(function(req, res, next) {
    res.redirect('/404.html');
});

app.use(function(err, req, res, next) {
    if(err && err.statusCode === 400){
        res.send(400, err);
    }else{
        console.log(err);
        res.send(500, {message: '服务器错误'});
    }
});

app.set('port', process.env.PORT || config.port);

var server = app.listen(app.get('port'), function() {
    console.log('Express server listening on port ' + server.address().port);
});

module.exports = app;
