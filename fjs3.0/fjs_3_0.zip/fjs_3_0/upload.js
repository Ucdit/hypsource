var fs = require('fs');
var formidable = require('formidable');
var util = require('util');
var path = require('path');


exports.upload = function(req, res, next){
    // if(!req.session.user_id){
    //     return res.send(400, {message: '用户未登录'});
    // }
    req.session.user_id = 1;
    
    var form = new formidable.IncomingForm();

    form.uploadDir = config.uploadDir;
    form.keepExtensions = true;
    form.maxFieldsSize = 2 * 1024 * 1024;

    form.parse(req, function(err, fields, files){
        //res.send(util.inspect({fields: fields, files: files}))
        if(Object.keys(files).length <= 0 || !files.Filedata){
            return res.send(400, {message: '没有选择文件'});
        }

        //客户端input的name必须是Filedata
        var filepath = files.Filedata.path.toLowerCase();
        var ext = path.extname(filepath);

        if(!config.allowedUploadFileType.indexOf(ext)){
            return res.send(400, {message: '只允许上传png, jpeg, jpg文件'});
        }

        var imgPath = '/upload/' + path.basename(files.Filedata.path);

        db.Upload.create({
            user_id: req.session.user_id,
            path: imgPath
        })
        .success(function(){
            res.send({
                imgurl: imgPath
            });
        })
        .error(function(err){
            logger.error({message: '保存上传文件路径到数据库失败'});
            return next(err);
        });
    });
};