var request = require('request');
var config = require('../../common/config.js');


exports.registerWithoutPassword = function(req, res, next){  
    var last_name = req.param('last_name');
    var phone = req.param('phone');
    var sms_code = req.param('sms_code');
    var type = req.param('type');  //type: 1, 2

    request({
        url: config.apiUrl + '/user',
        method: 'POST',
        form: {
            last_name: last_name,
            phone: phone,
            sms_code: sms_code,
            type: type
        }
    }, 
    function(err, response, body){
        if(err){
            return next("error", err);
        }else{
            return res.send(response.statusCode, body);
        }
    });
};