var request = require('request');
var config = require('../../common/config.js');


exports.getSmsCode = function(req, res, next){ 
    var phone = req.param('phone');

    request({
        url: config.apiUrl + '/sms_code',
        method: 'POST',
        form: {
            phone: phone
        }
    }, 
    function(err, response, body){
        if(err){
            return next("error", err);
        }else{
            return res.send(response.statusCode, body);
        }
    });
};

exports.getLoginSmsCode = function(req, res, next){
    var phone = req.param('phone');

    request({
        url: config.apiUrl + '/login_sms_code',
        method: 'POST',
        form: {
            phone: phone
        }
    }, 
    function(err, response, body){
        if(err){
            return next("error", err);
        }else{
            return res.send(response.statusCode, body);
        }
    });
};