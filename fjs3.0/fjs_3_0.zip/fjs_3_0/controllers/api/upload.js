var request = require('request');
var config = require('../../common/config.js');
var fs = require('fs');
var formidable = require('formidable');
var path = require('path');

exports.upload = function(req, res, next){  
    var form = new formidable.IncomingForm();

    form.uploadDir = config.uploadDir;
    form.keepExtensions = true;
    form.maxFieldsSize = 2 * 1024 * 1024;

    form.parse(req, function(err, fields, files){
        //res.send(util.inspect({fields: fields, files: files}))
        if(Object.keys(files).length <= 0 || !files.Filedata){
            return res.send(400, {message: '没有选择文件'});
        }

        //客户端input的name必须是Filedata
        var filepath = files.Filedata.path.toLowerCase();
        var ext = path.extname(filepath);

        if(!config.allowedUploadFileType.indexOf(ext)){
            return res.send(400, {message: '只允许上传png, jpeg, jpg文件'});
        }

        console.log(files.Filedata.path);
        request({
            url: config.apiUrl + '/upload_file',
            method: 'POST',
            formData: {
                Filedata: fs.createReadStream(files.Filedata.path)
            }
        }, 
        function(err, response, body){
            if(err){
                return next("error", err);
            }else if(response.statusCode!==200){
                return next("error", response.statusCode, body);
            }else{
                return res.send({
                    message: '上传成功'
                });
            }
        });
    });
};