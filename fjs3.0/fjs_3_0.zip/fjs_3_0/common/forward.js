var request = require('request')

module.exports = function(pattern, host){
  return function(req, res, next){
    if(req.url.match(pattern)){
      var api_path = req.url.match(pattern)[1]
        , api_url = [host, api_path].join('/');
        console.log(api_url)
      req.pipe(request[req.method.toLowerCase()](api_url)).pipe(res);
    }else{
      next();
    }
  }
};