var extend = require('utils-merge');

module.exports = (function(){

    //把所有通用的配置放在这里
    var config = {
        allowedUploadFileType: ['png', 'jpeg', 'jpg'],
        uploadDir: __dirname + '/../img_buffer/',
    }

    switch(process.env.NODE_ENV){
        case 'production':
            console.log('Using production configuration');

            return extend(config, {
                port: 4000,
                apiUrl: 'http://api.fangjinsuo.com:4002',
            });
        case 'stage':
            console.log('Using stage configuration');

            return extend(config, {
                port: 4000,
                apiUrl: 'http://localhost:4002',
            });
        case 'beta':
            console.log('Using mobile_test configuration');
            return extend(config, {
                port: 4000,
                apiUrl: 'http://betaapi.fangjinsuo.com:4002',
            })
        case 'suyuan':
            console.log('Using suyuan configuration');
            return extend(config, {
                port: 4000,
                apiUrl: 'http://localhost:4002',
            });
        case 'jingjing':
            console.log('Using jingjing configuration');
            return extend(config, {
                port: 3000,
                apiUrl: 'http://localhost:4002',
            });
        case 'baizeming':
            console.log('Using baizeming configuration');
            return extend(config, {
                port: 4000,
                apiUrl: 'http://localhost:4002',
            });
        
        default:
            throw new Error('Missing process.env.NODE_ENV');
    }
})();