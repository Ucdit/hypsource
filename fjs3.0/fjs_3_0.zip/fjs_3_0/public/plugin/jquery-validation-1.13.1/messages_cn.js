jQuery.extend(jQuery.validator.messages, {
    required: "必选字段",
	remote: "请修正该字段",
	email: "请输入正确电子邮箱",
	url: "请输入合法的网址",
	date: "请输入合法的日期",
	dateISO: "请输入合法的日期 (ISO).",
	number: "请输入数字",
	digits: "只能输入整数",
	creditcard: "请输入信用卡号",
	equalTo: "请再次输入相同的值",
	accept: "请输入拥有合法后缀名的字符串",
	maxlength: jQuery.validator.format("请输入一个 长度最多是 {0} 的字符串"),
	minlength: jQuery.validator.format("请输入一个 长度最少是 {0} 的字符串"),
	rangelength: jQuery.validator.format("请输入 一个长度介于 {0} 和 {1} 之间的字符串"),
	range: jQuery.validator.format("请输入一个介于 {0} 和 {1} 之间的值"),
	max: jQuery.validator.format("请输入一个最大为{0} 的值"),
	min: jQuery.validator.format("请输入一个最小为{0} 的值")
});

jQuery.validator.addMethod('ChinaPhone',function(value,element){
                if(!value.match(/^(1[3|4|5|7|8])[0-9]{9}$/)){
                    return false;
                }else{
                    return true;
                }
        }, "号码格式不正确");

var RULE = {
	/*
		首页
	 */
	index:{
		// 房产抵押贷
		mortgage_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,
			},
			city_indexcity:{
				min:1,
				max:4999,
			},
			sms_code:{
				required:true,
				minlength:6,

			},
			name:{
				required:true,
				minlength:2,

			},
			worth:{
				required:true,
				digits:true,
				min:30,

			},
			amount_money:{
				required:true,
				digits:true,
				min:5,
			}

		},
		mortgage_messages:{
			phone:{
				required:"请输入手机",
			},
			last_name:{
				required:"请输入姓氏",
			},
			city_indexcity:{
				min:'请选择城市',
				max:'请选择城市'
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",
			},
			worth:{
				required:"请输入房产估值",
				number:"请输入整数",
				min:"不小于30万"
			},
			amount_money:{
				required:"请输入融资金额",
				number:"请输入整数",
				min:"不小于5万"
			}
		},
		// 其他需求类型
		other_rule:{
			phone:{
				required:true,
				ChinaPhone:true,
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			},
			name:{
				required:true,
				minlength:2,
			},
			worth:{
				required:true,
				digits:true,
				min:30
			},
			city_usehousecity:{
				max:4999,
				min:1,
			}
		},
		other_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"
			},
			last_name:{
				required:"请输入姓氏",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",

			},
			worth:{
				required:"请输入房产估值",
				number:"请输入整数",
				min:"不小于30万"
			},
			city_usehousecity:{
				max:'请选择城市',
				min:'请选择城市'
			}
		},
	},
	/*
		注册页
	 */
	register:{
		// 普通用户注册
		nReg_rule:{
			phone:{
				required:true,
				ChinaPhone:true,
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			},
			password:{
				required:true,
				minlength:6,
			}
		},
		nReg_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"
			},
			last_name:{
					required:"请输入姓氏",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			password:{
				required:"请输入密码",
				minlength:"密码不少于6位"
			}
		},
		// 信贷经理注册
		mReg_rule:{
			phone:{
				required:true,
				ChinaPhone:true,				
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			},
			password:{
				required:true,
				minlength:6,

			}
		},
		mReg_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"
			},
			last_name:{
				required:"请输入姓氏",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			password:{
				required:"请输入密码",
				minlength:"密码不少于6位"

			}
		},
	},
	/*
		登录页面
	 */
	login : {
		// 普通短信登录
		nLog_sms_rule:{
			phone:{
				required:true,
				ChinaPhone:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			}
		},
		nLog_sms_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"			
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
		},
		// 普通密码登录
		nLog_putong_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			password:{
				required:true,			
				minlength:6,
			}
		},
		nLog_putong_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"	
			},
			password:{
				required:"请输入密码",
				minlength:"密码不少于6位"
			},
		},
		// 信贷用户短信登录
		mLog_sms_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			sms_code:{
				required:true,
				minlength:6,
			}
		},
		mLog_sms_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"	
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
		},
		// 信贷用户密码登录
		mLog_putong_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			password:{
				required:true,
				minlength:6,

			}
		},
		mLog_putong_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"	
			},
			password:{
				required:"请输入密码",
				minlength:"密码不少于6位"
			},
		},
	},
	// 房产抵押贷
	realestate_mortgage:{
		// 房产抵押贷
		mortgage_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,

			},
			name:{
				required:true,
				minlength:2,

			},
			worth:{
				required:true,
				digits:true,
				min:30
			},
			amount_money:{
				required:true,
				digits:true,
				min:5,
			},
			city_mortgagecity:{
				max:4999,
				min:1
			},
			city_applycity:{
				max:4999,
				min:1,
			}

		},
		mortgage_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"	
			},
			last_name:{
				required:"请输入姓氏",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",

			},
			worth:{
				required:"请输入房产价值",
				number:"请输入整数",
				min:"不小于30万",

			},
			amount_money:{
				required:"请输入融资金额",
				number:"请输入整数",
				min:"不小于5万",
			},
			city_mortgagecity:{
				min:'请选择城市',
				max:'请选择城市'
			},
			city_applycity:{
				max:'请选择城市',
				min:'请选择城市'
			}
		},
	},
	// 以房理财
	realestate_financing:{
		financing_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,

			},
			name:{
				required:true,
				minlength:2,

			},
			worth:{
				required:true,
				digits:true,
				min:30,
			},
			city_financingcity:{
				min:1,
				max:4999,
			}
		},
		financing_messages:{
			phone:{
				required:"请输入手机",
				minlength:"请输入11位手机"	
			},
			last_name:{
				required:"请输入姓氏",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",

			},
			worth:{
				required:"请输入房产估值",
				digits:"请输入整数",
				min:"不小于30万",
			},
			city_financingcity:{
				min:'请选择城市',
				max:'请选择城市'
			}
		},
	},
	// 以房买房
	realestate_buy:{
		buy_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,

			},
			sms_code:{
				required:true,
				minlength:6,
			},
			name:{
				required:true,
				minlength:2,

			},
			worth:{
				required:true,
				digits:true,
				min:30,
			},
			amount_money:{
				required:true,
				digits:true,
				min:5,
			},
			city_buycity:{
				min:1,
				max:4999
			}
		},
		buy_messages:{
			phone:{
				required:"请输入电话",
				minlength:"请输入11位手机"	
			},
			last_name:{
				required:"请输入姓名",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码",
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",
			},
			worth:{
				required:"请输入房产价值",
				number:"请输入整数",
				min:"不小于30万",
			},
			amount_money:{
				required:"请输入融资金额",
				number:"请输入整数",
				min:"不小于5万",
			},
			city_buycity:{
				max:"请选择城市",
				min:'请选择城市'
			}
		},
	},
	// 以房移民
	realestate_immigrant:{
		immigrant_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			},
			name:{
				required:true,
				minlength:2,
			},
			worth:{
				required:true,
				digits:true,
				min:30,
			},
			amount_money:{
				required:true,
				digits:true,
				min:5,
			}
		},
		immigrant_messages:{
			phone:{
				required:"请输入电话",
				minlength:"请输入11位手机"	
			},
			last_name:{
				required:"请输入姓名",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码"
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",
			},
			worth:{
				required:"请输入房产价值",
				number:"请输入整数",
				min:"不小于30万",
			},
			amount_money:{
				required:"请输入融资金额",
				number:"请输入整数",
				min:"不小于5万",
			}
		},
	},
	// 以房教育
	realestate_educate:{
		educate_rule:{
			phone:{
				required:true,
				ChinaPhone:true
			},
			last_name:{
				required:true,
			},
			sms_code:{
				required:true,
				minlength:6,
			},
			name:{
				required:true,
				minlength:2,
			},
			worth:{
				required:true,
				digits:true,
				min:30
			},
			amount_money:{
				required:true,
				digits:true,
				min:5
			}
		},
		educate_messages:{
			phone:{
				required:"请输入电话",
				minlength:"请输入11位手机",
			},
			last_name:{
				required:"请输入姓名",
			},
			sms_code:{
				required:"请输入验证码",
				minlength:"请输入6位验证码",
			},
			name:{
				required:"请输入小区名称",
				minlength:"两个字以上",
			},
			worth:{
				required:"请输入房产价值",
				number:"请输入整数",
				min:"不小于30万",
			},
			amount_money:{
				required:"请输入融资金额",
				number:"请输入整数",
				min:"不小于5万",
			}
		},
	},

	// 产品详情
	product_detail:{
		product_rule:{
			interest:{
				required:true,
				number:true,
			},

			debt_duration:{
				required:true,
			},

			type:{
				required:true,
				min:1,
			},
			house_num:{
				required:true,
			},
			age:{
				required:true,
				number:true,
			}
		},
		product_messages:{
			interest:{
				required:"请输入预期年利率",
				number:'请输入正确的利率'
			},
			debt_duration:{
				required:"请输入贷款期限",
			},
			type:{
				required: '请选择房产类型',
				min:'请选择房产类型',
			},
			house_num:{
				required:"请输入家庭房产数量",
			},
			age:{
				required:"请输入房龄",
				number:"请输入正确的房龄"
			},
		},
	},

}
























