var nsNeedList = function(){
    var ns = {};

    ns.listener = function(){
        $( "#created_after" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $( "#created_before" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $('#created_after').change(function(){
            searchNeed('1');
        })

        $('#created_before').change(function(){
            searchNeed('1');
        })

        $('.js-searchPhone').click(function(event) {
            event.preventDefault();
            /* Act on the event */
            searchNeed('1');
        });

        $('.province-select').change(function(event) {
            searchNeed('1');
        });
        var sel = ''
        for (var i = 0; i < province.length; i++) {
            sel += '<option value="'+province[i].areaid+'">'+province[i].areaName+'</option>';
        };
        $(sel).appendTo('.province-select');
        // 需求类型按钮
        $('.js-needtype').click(function(event) {
            /* Act on the event */
            type = $(event.target).data('type');
            var text = $(event.target).text();
            $("#needtype").text(text);
            searchNeed('1');
        });
        // 需求状态
        $('.js-status').click(function(event) {
            /* Act on the event */
            status = $(event.target).data('status');
            var text = $(event.target).text();
            $("#status").text(text);
            searchNeed('1');
        });
        var type = '';
        var status = '';
        var isPaginationCreated = false;

        searchNeed('1');

        function searchNeed(page){
            var url='';
            // 电话
            var phone = $('.phone-input').val();
            if (phone) {
                url +='&phone='+phone;
            };
            // 时间
            var createdAfter = $('#created_after').val();
            var createdBefore = $('#created_before').val();
            // 城市
            var city = $('.province-select').val();
            url += '&city=' + city;
            // needtype
            if (type) {
                url += '&needtype=' + type;
            };
            if (status) {
                url += '&status=' + status;
            };
            if(createdAfter){
                url += '&created_after=' + createdAfter;
            }

            if(createdBefore){
                url += '&created_before=' + createdBefore;
            }
            console.log(url)
            $.ajax({
                url: nsTools.apiUrl + '/admin/need/search?atoken='
                    + nsTools.getCookie('atoken') + '&page=' + page +url,
                type: 'GET'
            })
            .then(function(data){
                $("#js_need_list").text('');
                $("#js_need_list_template").tmpl(data.rows).appendTo('#js_need_list');
                c(data)

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,searchNeed);
                    isPaginationCreated = true;
                }

                $('.js_status_select').change(function(){
                    if($(this).val()==='0'){
                        return
                    }

                    $.ajax({
                        url: nsTools.apiUrl + '/admin/need/' + $(this).attr('data-need-id'),
                        type: 'PUT',
                        data: {
                            status: $(this).val(),
                            atoken: nsTools.getCookie('atoken')
                        }
                    })
                    .then(function(data){
                        searchNeed(page);
                    })
                    .fail(function(jqXHR, textStatus, err){
                        alert(jqXHR.responseText);
                    });
                });
            //-1无效 1发布 2申请 3对接 4失败
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();