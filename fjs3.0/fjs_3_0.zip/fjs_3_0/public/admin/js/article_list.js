var nsArticleList = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');
        
        $('.sidebar .nav li.article_list').tab('show');

        $.ajax({
            url: nsTools.apiUrl + '/admin/article/search?atoken=' + atoken,
            type:'get',
            success:function(data){
                $("#article_list_template").tmpl(data).appendTo('#article_list_container');
            }
        });
    };
    
    return ns;
}();