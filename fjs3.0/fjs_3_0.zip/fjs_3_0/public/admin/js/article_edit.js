var nsArticleEdit = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');

        var editor = UM.getEditor('ue_editor');

        var id = parseInt($.url('?id', location.href));

        //初始化上传插件
        nsTools.uploadifyAdmin({
            inputId: '#js_image_input',
            height: 40,
            width: 100,
            onDialogOpen: function(){
                //清空图片显示区域
                $('.js_image').text('');
            },
            onUploadSuccess: function(file, data, response){
                data = JSON.parse(data);

                $('.js_image').append('<img src="' 
                    + nsTools.imgServer + data.imgurl 
                    +'" width="100" height="100" />');

                $('#image').val(data.imgurl);
            }
        })

        //获取信息
        $.ajax({
            url: nsTools.apiUrl + '/admin/article/' + id + '?atoken=' + atoken,
            type: 'get',
            success:function(data){
                data.created_at = nsTools.Date_Format(data.created_at, 'yyyy-MM-dd');
                $('input[name="title"]').val(data.title);
                $('input[name="link"]').val(data.link);
                $('input[name="publish_time"]').val(data.publish_time);
                $('#image').val(data.image);
                $('.js_image').append('<img src="' 
                    + nsTools.imgServer + data.image + '"'
                    + ' width="100" height="100" />');
                $('#source').val(data.source);
                $('.article_id').text(id);
                editor.ready(function(){
                    editor.setContent(data.content);
                });
            }
        });

        //编辑信息
        $('#btn_submit').click(function(){
            $.ajax({
                url: nsTools.apiUrl + '/admin/article/' + id,
                type:'put',
                data: {
                    title: $('#title').val(),
                    link: $('#link').val(),
                    publish_time: $('#publish_time').val(),
                    content: editor.getContent(),
                    atoken: atoken,
                    image: $('#image').val(),
                    source: $('#source').val()
                },
                success:function(data){
                    alert("编辑成功");
                    location.href="/fjs/article_list";
                }
            });
        });

    };
    
    return ns;
}();