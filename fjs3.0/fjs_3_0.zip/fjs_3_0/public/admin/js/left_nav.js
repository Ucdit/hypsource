var nsLeftNav = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');

        if(!atoken){
            $('.left_nav').css("visibility", "hidden");
        }

        if(location.pathname === '/fjs'){
            $('.fjs').addClass('active');
        }else{
            var page = location.pathname.substring(5).replace(/\//, '');
            $('.' + page).addClass('active');
        }

        $('.left_nav .logout').click(function(e){
            e.preventDefault();

            $.ajax({
                url: nsTools.apiUrl + '/admin/logout',
                type: 'POST',
                data: {
                    atoken: nsTools.getCookie('atoken'),
                    aid: nsTools.getCookie('aid')
                }
            })
            .then(function(){
                nsTools.setCookie('atoken', '');
                nsTools.getCookie('aid', '');
                location.href = '/fjs'
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        })
    };

    return ns;
}();