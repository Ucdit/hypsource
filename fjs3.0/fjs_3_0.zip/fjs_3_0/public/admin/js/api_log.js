var nsApiLog = function(){
    var ns = {};

    ns.listener = function(){
        var isPaginationCreated = false;

        searchApiLog('1');

        function searchApiLog(page){
            var atoken = nsTools.getCookie('atoken');

            $.ajax({
                url: nsTools.apiUrl + '/admin/access_log/list?atoken=' 
                    + atoken + '&page=' + page,
                type: 'GET'
            })
            .then(function(data){
                $('#js_log_list').text('');
                $('#js_log_list_tmpl').tmpl(data.rows).appendTo('#js_log_list');

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,searchApiLog);
                    isPaginationCreated = true;
                }
            })
        }
    };

    return ns;
}();