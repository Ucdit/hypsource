var nsLogin = function(){
    var ns = {};

    ns.listener = function(){
        $('#submit_btn').on('click', function(){
            $.ajax({
                url: nsTools.apiUrl + '/admin/login',
                type: 'POST',
                data: {
                    username: $('#username').val(),
                    password: $('#password').val()
                }
            })
            .then(function(data){
                if(data.code !== 1){
                    alert(data)
                }else{
                    nsTools.setCookie('atoken', data.token);
                    nsTools.setCookie('aid', data.admin.id);
                    location.href = '/fjs';
                }
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });

            return false;
        });
    };

    return ns;
}();