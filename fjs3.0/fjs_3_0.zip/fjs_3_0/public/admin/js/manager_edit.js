var nsManagerEdit = function(){
    var ns = {};

    ns.listener = function(){
        var manager_id = url('?manager_id');
        var atoken = nsTools.getCookie('atoken');

        if(!atoken){
            location.href = '/fjs';
        }

        $.ajax({
            url: nsTools.apiUrl + '/admin/manager/' 
                + manager_id + '?atoken=' + atoken,
            type: 'get'
        })
        .then(function(data){
            $('#edit_form').tmpl(data).appendTo($('.rightContainer'));

            //初始化上传文件功能
            initUpload();
            
            //表单提交事件
            registerSubmitEvent(manager_id, atoken);
        })
        .fail(function(jqXHR, textStatus, err){
            alert(jqXHR.responseText);
        });

        function registerSubmitEvent(manager_id, atoken){
            $('.js_submit_btn').click(function(){
                $.ajax({
                    url: nsTools.apiUrl + '/admin/manager/' + manager_id,
                    type: 'put',
                    data: $('#js_user_form').serialize() + '&atoken=' + atoken
                })
                .then(function(data){
                    location.href = '/fjs/manager_list';
                })
                .fail(function(jqXHR, textStatus, err){
                    alert(jqXHR.responseText);
                });
            });
        }

        //初始化上传文件功能
        function initUpload(){
            //身份证
            createUploadInput('#id_card_img_upload',
                '.id_card_img',
                '#id_card_img');

            //名片
            createUploadInput('#name_card_img_upload',
                '.name_card_img',
                '#name_card_img');

            //从业资格证
            createUploadInput('#license_img_upload',
                '.license_img',
                '#license_img');
        }

        /**
         * [createUploadInput description]
         * @param  {String} uploadify input的id
         * @param  {String} 显示图片的div class
         * @param  {String} 图片输入框id
         * @return undefined
         */
        function createUploadInput(inputId, showImgAreaClass, dataInputId){
            nsTools.uploadifyAdmin({
                inputId: inputId,
                height: 40,
                width: 100,
                onDialogOpen: function(){
                    //清空图片显示区域
                    $(showImgAreaClass).text('');
                },
                onUploadSuccess: function(file, data, response){
                    data = JSON.parse(data);

                    $(showImgAreaClass).append('<img src="' 
                        + nsTools.imgServer + data.imgurl 
                        +'" width="100" height="100" />');

                    $(dataInputId).val(data.imgurl);
                }
            });
        }
    };

    return ns;
}();