var nsUserList = function(){
    var ns = {};

    ns.listener = function(){
        var isPaginationCreated = false;

        var atoken = nsTools.getCookie('atoken');

        $( "#created_after" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $( "#created_before" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $('#created_after').change(function(){
            searchUser('1');
        })

        $('#created_before').change(function(){
            searchUser('1');
        })
        var  havingNeed = '';

        $('#having_need').click(function(event){
            havingNeed = $(event.target).data('status');
            var text = $(event.target).text();
            $("#having_need_b").text(text);
            searchUser('1');
        });

        searchUser(1);
        
        function searchUser(page){
            var url = nsTools.apiUrl + '/admin/user/search' 
                    + '?atoken=' + atoken + '&page=' + page;
            var createdAfter = $('#created_after').val();
            var createdBefore = $('#created_before').val();

            if(createdAfter){
                url += '&created_after=' + createdAfter
            }

            if(createdBefore){
                url += '&created_before=' + createdBefore
            }

            if(havingNeed == '1' || havingNeed == '2'){
                url += '&having_need=' + havingNeed
            }

            $.ajax({
                url: url,
                type: 'get'
            })
            .then(function(data){
                $('#js_user_list').text('');
                $("#js_user_list_tmpl").tmpl(data.rows).appendTo('#js_user_list');
                
                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,searchUser);
                    isPaginationCreated = true;
                }
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();