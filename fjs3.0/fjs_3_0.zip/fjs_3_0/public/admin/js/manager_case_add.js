var nsManagerCaseAdd = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');

        $('#case_form').validate();
        
        $('#btn_submit').click(function(){
            if($('#case_form').valid()){
                $.ajax({
                    url: nsTools.apiUrl + '/admin/case',
                    type: 'POST',
                    data: $('#case_form').serialize() + '&atoken=' + atoken
                })
                .then(function(data){
                    alert('添加成功')
                })
                .fail(function(jqXHR, textStatus, err){
                    alert(jqXHR.responseText);
                });
            }
        });
    };

    return ns;
}();