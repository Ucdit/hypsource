var nsJzSmsLog = function(){
    var ns = {};

    ns.listener = function(){
        var isPaginationCreated = false;

        search('1');

        function search(page){
            var atoken = nsTools.getCookie('atoken');
            $.ajax({
                url: nsTools.apiUrl + '/admin/jz_sms_log/list?atoken=' + atoken
                    + '&page=' + page,
                type: 'GET'
            })
            .then(function(data){
                $('#js_log_list').text('');
                $('#js_log_list_tmpl').tmpl(data.rows).appendTo($('#js_log_list'));

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,search);
                    isPaginationCreated = true;
                }
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();