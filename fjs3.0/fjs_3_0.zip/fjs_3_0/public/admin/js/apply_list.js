var nsApplyList = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');
        var isPaginationCreated = false;

        search('1');

        $('#btn_search').click(function(e){
            e.preventDefault();
            search('1');
        });

        function search(page){
            var url = nsTools.apiUrl + '/admin/apply/search?atoken='
                    + atoken + '&page=' + page;

            var manager_phone400 = $('#manager_phone400').val();
            if(manager_phone400){
                url += '&manager_phone400=' + manager_phone400;
            }

            var manager_phone = $('#manager_phone').val();
            if(manager_phone){
                url += '&manager_phone=' + manager_phone;
            }

            $.ajax({
                url: url
            })
            .then(function(data){
                c(data)
                $('#js_apply_list').text('');
                $("#js_apply_list_tmpl").tmpl(data.rows).appendTo('#js_apply_list');

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,search);
                    isPaginationCreated = true;
                }

                $('.js_apply_op').change(function(){
                    $.ajax({
                        url: nsTools.apiUrl + '/admin/apply/' + $(this).attr('data-apply-id'),
                        type: 'put',
                        data: {
                            atoken: atoken,
                            status: $(this).val()
                        }
                    })
                    .then(function(data){
                        search(page);
                    })
                    .fail(function(jqXHR, textStatus, err){
                        alert(jqXHR.responseText);
                    });
                })
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();