var nsManagerCaseList = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');

        $.ajax({
            url: nsTools.apiUrl + '/admin/case_list?atoken=' + atoken,
            type: 'get'
        })
        .then(function(data){
            $('#case_list_tmpl').tmpl(data).appendTo('#case_list_container');
        })
        .fail(function(jqXHR, textStatus, err){
            alert(jqXHR.responseText);
        });
    };

    return ns;
}();