var nsEditNeed = function(){
    var ns = {};

    ns.listener = function(){
        var need_id = url('?need_id');
        var atoken = nsTools.getCookie('atoken');

        if(!atoken){
            location.href = '/fjs';
        }

        $.ajax({
            url: nsTools.apiUrl + '/need/' + need_id,
            type: 'GET'
        })
        .then(function(data){
            //把需求数据绑定到表单
            $("#edit_form").tmpl(data).appendTo('.rightContainer');

            //初始化城市选择列表
            $('.js_province_tmpl').tmpl(nsArea.getProvince()).appendTo('.js_province_list');
            $('.js_province_list').change(function(){
                var provinceId = $(this).val();
                $('.js_city_list').text('');
                $('.js_city_tmpl').tmpl(nsArea.getCity(provinceId)).appendTo('.js_city_list');
            });


            //根据市查找省, 房产的数据里面只有city
            var province = nsArea.findProvinceByCityId(data.Realestate.city);
            //填充城市列表
            $('.js_city_tmpl').tmpl(nsArea.getCity(province.areaid)).appendTo('.js_city_list');

            //选择省
            $('.js_province_list option[value=' + province.areaid + ']').attr('selected', '');
            
            //选择市
            $('.js_city_list option[value='+data.Realestate.city+']').attr('selected', '');
        
            //初始化文件上传插件
            initFileUpload();

            //添加form验证事件
            $('#js_user_form').validate();
            $('#js_realestate_form').validate();

            $('.js_submit_btn').click(function(){
                //验证表单
                // if(!$('#js_user_form').valid()
                //     || !$('#js_realestate_form').valid()
                //     || !$('#js_need_form').valid()){
                //     return;
                // }

                $.ajax({
                    url: nsTools.apiUrl + '/admin/need/' + need_id,
                    type: 'PUT',
                    data: $('#js_need_form').serialize() + '&atoken=' + atoken
                })
                .then(function(){
                    return $.ajax({
                        url: nsTools.apiUrl + '/admin/user/' + $('#user_id').val(),
                        type: 'PUT',
                        data: $('#js_user_form').serialize() + '&atoken=' + atoken
                    })
                })
                .then(function(){
                    return $.ajax({
                        url: nsTools.apiUrl + '/admin/realestate/' + $('#realestate_id').val(),
                        type: 'PUT',
                        data: $('#js_realestate_form').serialize() + '&atoken=' + atoken
                    })
                })
                .done(function(){
                    location.href = '/fjs/need_list';
                })
                .fail(function(jqXHR, textStatus, err){
                    alert(jqXHR.responseText);
                });
            });
        })
        .fail(function(jqXHR, textStatus, err){
            alert(jqXHR.responseText);
        });

        function initFileUpload(){
            nsTools.uploadifyAdmin({
                inputId: '#js_realestate_img_upload',
                height: 40,
                width: 100,
                onDialogOpen: function(){
                    //清空图片显示区域
                    $('.js_realestate_img_list').text('');
                },
                onUploadSuccess: function(file, data, response){
                    data = JSON.parse(data);

                    $('.js_realestate_img_list').append('<img src="' 
                        + nsTools.imgServer + data.imgurl 
                        +'" width="100" height="100" />');
                    if(!$('#js_realestate_imgs').val()){
                        $('#js_realestate_imgs').val(data.imgurl);
                    }else{
                        $('#js_realestate_imgs').val($('#js_realestate_imgs').val() 
                            + ';' +data.imgurl);
                    }
                }
            });

            //房产价格走势图
            nsTools.uploadifyAdmin({
                inputId: '#js_price_img_upload',
                height: 40,
                width: 100,
                multi: false,
                onDialogOpen: function(){
                    //清空图片显示区域
                    $('.js_price_img_list').text('');
                },
                onUploadSuccess: function(file, data, response){
                    data = JSON.parse(data);

                    $('.js_price_img_list').append('<img src="' + nsTools.imgServer + data.imgurl +'" width="100" height="100" />')
                    
                    $('#js_price_img').val(data.imgurl);
                }
            })
        }
    };  

    return ns;
}();