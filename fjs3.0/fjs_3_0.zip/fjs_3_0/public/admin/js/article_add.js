var nsArticleAdd = function(){
    var ns = {};

    ns.listener = function(){
        var atoken = nsTools.getCookie('atoken');

        var editor = UM.getEditor('ue_editor');

        nsTools.uploadifyAdmin({
            inputId: '#js_image_input',
            height: 40,
            width: 100,
            onDialogOpen: function(){
                //清空图片显示区域
                $('.js_image').text('');
            },
            onUploadSuccess: function(file, data, response){
                data = JSON.parse(data);

                $('.js_image').append('<img src="' 
                    + nsTools.imgServer + data.imgurl 
                    +'" width="100" height="100" />');

                $('#image').val(data.imgurl);
            }
        })

        $('#btn_submit').click(function(){
            $.ajax({
                url: nsTools.apiUrl + '/admin/article',
                type:'post',
                data: {
                    title: $('#title').val(),
                    link: $('#link').val(),
                    content: editor.getContent(),
                    atoken: atoken,
                    image: $('#image').val(),
                    source: $('#source').val()
                }
            })
            .then(function(data){
                alert("添加成功");
                location.href="/fjs/article_list";
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        });
    };
    
    return ns;
}();