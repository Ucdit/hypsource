var nsAddManagerToOrg = function(){
    var ns = {};

    ns.listener = function(){
        var org_id = url('?org_id');
        var atoken = nsTools.getCookie('atoken');

        $.ajax({
            url: nsTools.apiUrl + '/admin/org/' + org_id + '?atoken=' + atoken 
        })
        .then(function(data){
            $('.org_info').append(data.name);
        })
        .fail(function(jqXHR, textStatus, err){
            alert(jqXHR.responseText);
        })

        $('#btn_submit').click(function(){
            var phone = $('#phone').val().trim();
            var type = $('input[name=phone]:checked').val();

            if(phone){
                addManager();
            }else{
                alert('手机号码不能为空')
            }

            function addManager(){
                $.ajax({
                    url: nsTools.apiUrl + '/admin/add_manager_to_org',
                    type: 'POST',
                    data: {
                        org_id: org_id,
                        phone: phone,
                        atoken: atoken,
                        type: type
                    }
                })
                .then(function(data){
                    alert('添加成功');
                })
                .fail(function(jqXHR, textStatus, err){
                    alert(jqXHR.responseText);
                })
            }
        });
    };

    return ns;
}();