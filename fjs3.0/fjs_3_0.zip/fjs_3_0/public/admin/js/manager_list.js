var nsManagerList = function(){
    var ns = {};

    ns.listener = function(){
        //是否已经添加分页
        var isPaginationCreated = false;
        $('.js-searchPhone').click(function(event) {
            event.preventDefault();
            /* Act on the event */
            searchManager('1');
        });
        searchManager('1');

        $( "#created_after" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $( "#created_before" ).datepicker({
            dateFormat: "yy-mm-dd"
        });

        $('#created_after').change(function(){
            searchManager('1');
        })

        $('#created_before').change(function(){
            searchManager('1');
        })

        $('.province-select').change(function(event) {
            searchManager('1');
        });
        var sel = ''
        for (var i = 0; i < province.length; i++) {
            sel += '<option value="'+province[i].areaid+'">'+province[i].areaName+'</option>';
        };


        $(sel).appendTo('.province-select');
        // 需求类型按钮
        $('.js-type').click(function(event) {
            /* Act on the event */
            type = $(event.target).data('type');
            var text = $(event.target).text();
            $("#type").text(text);
            searchManager('1');
        });
        // 需求状态
        $('.js-status').click(function(event) {
            /* Act on the event */
            status = $(event.target).data('status');
            var text = $(event.target).text();
            $("#status").text(text);
            c(status)
            searchManager('1');
        });
        var type = '';
        var status = '';

        function searchManager(page){
            var url = '';
            var phone = $('.phone-input').val();
            // 时间
            var createdAfter = $('#created_after').val();
            var createdBefore = $('#created_before').val();

            var city = $('.province-select').val();
            if (city) {
                url += '&city=' + city;
            };
            
            if (phone) {
                url +='&phone='+phone;
            };
            if (status) {
                url += '&status=' + status;
            };
            if (type) {
                url += '&type=' + type;
            };
            if(createdAfter){
                url += '&created_after=' + createdAfter;
            }

            if(createdBefore){
                url += '&created_before=' + createdBefore;
            }
            $.ajax({
                url: nsTools.apiUrl + '/admin/manager/search?atoken=' 
                + nsTools.getCookie('atoken') + '&page=' + page + url,
                type: 'GET'
            })
            .then(function(data){
                console.log(data)
                $('#js_manager_list').text('');
                $("#js_manager_list_template").tmpl(data.rows).appendTo('#js_manager_list');

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    c(totalPages)
                    nsTools.pagination('pagination',totalPages,searchManager);
                }
                

                $('.js_status_select').change(function(){
                    $.ajax({
                        url: nsTools.apiUrl + '/admin/manager/' + $(this).attr('data-user-id'),
                        type: 'PUT',
                        data: {
                            status: $(this).val(),
                            atoken: nsTools.getCookie('atoken')
                        }
                    })
                    .then(function(data){
                        searchManager(page);
                    })
                });
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();