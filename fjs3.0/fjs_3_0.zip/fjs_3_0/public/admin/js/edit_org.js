var nsEditOrg = function(){
    var ns = {};

    ns.listener = function(){
        var org_id = url('?org_id');

        var atoken = nsTools.getCookie('atoken');
        if(!atoken){
            location.href = '/fjs';
        }

        $.ajax({
            url: nsTools.apiUrl + '/admin/org/' + org_id + '?atoken=' + atoken,
            type: 'GET'
        })
        .then(function(data){
            $('#edit_form_tmpl').tmpl(data).appendTo('.org_form_wrap');
            c(data)

            initUpload();

            $.ajax({
                url: nsTools.apiUrl + '/admin/get_product/' 
                    + org_id + '?atoken=' + atoken,
                type: 'GET'
            })
            .then(function(product){
                $('#product_form_tmpl').tmpl(product).appendTo('.product_form_wrap');
            
                /*城市选择相关操作的js  开始*/
                //房产所在城市
                var cityHouse = 'productcity';  
                var cityTargetArea = 'targetAreacity';

                //省份赋值
                var cityIndex_tmplId   = 'city-list_' + cityHouse;
                var cityIndex_appendTo = '.regions-page1_' + cityHouse;

                var cityTargetArea_tmplId = 'city-list_' + cityTargetArea;
                var cityTargetArea_appendTo = '.regions-page1_' + cityTargetArea;

                var appendTo = {};
                appendTo[cityIndex_tmplId] = cityIndex_appendTo;
                appendTo[cityTargetArea_tmplId] = cityTargetArea_appendTo;

                //省份赋值
                nsTools.getProvince([cityIndex_tmplId, cityTargetArea_tmplId], appendTo);

                //城市选择的显示与隐藏
                $('#citybtn_' + cityHouse).click(function(){
                    $('.detail-location-picker_' + cityHouse).toggle();
                    $('input[name=address]').attr('disabled',false);
                    $('#addressWarn').hide();
                });

                //业务地域城市选择 (多选)
                $('#citybtn_' + cityTargetArea).click(function(){
                   $('.detail-location-picker_' + cityTargetArea).toggle();
                });

                $('.region-level-tabs li').click(function(){
                    $('input[name=address]').removeAttr('disabled');
                    if ($(this).index() === 0) {
                        $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                        $('.region-level-tabs li').addClass('current').not(this).remove();
                        $('.regions-page1_' + cityHouse).show();   
                    }
                });

                //选择全部
                $('.allcity_' + cityHouse).click(function(){
                    $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
                    $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
                    $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
                    $('.close_' + cityHouse).click();
                });



                /*********服务区域多选控制 开始 ********/
                $('.p_c_toggle_' + cityTargetArea + ' li').click(function() {
                    $("#manyprovinces_span").show();
                    $('#city_input_' + cityTargetArea).val('');
                    $("#manycitys_span").hide();
                    if ($(this).index() === 0) {
                        $('.regions-page2_' + cityTargetArea + ' li').remove();
                        $('.p_c_toggle_' + cityTargetArea + ' li').addClass('current').not(this).remove();
                        $('.regions-page1_' + cityTargetArea).show();
                    }
                });

                //选择多个省份的控制开关
                $('input[name="manyprovinces"]').click(function() {
                    //开启省份多选模式
                    if ($(this).prop("checked")) {
                        $('#city_input_' + cityTargetArea).val('');
                        $('#citybtn_' + cityTargetArea).val('请选择地区');
                        //设置省份模式标识
                        $('#province_type').val(1);
                        $('#city_type').val(0);
                        $('input[name="everycity"]').each(function() {
                            $(this).click(function() {
                                var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                                if ($(this).prop("checked")) {
                                    if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                        $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                                    }
                                } else {
                                    if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                        $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));
                                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                                    }
                                }
                            });
                        }).show();
                        $('.p_area').removeAttr("onclick");
                    } else {
                        $('#citybtn_' + cityTargetArea).val('请选择地区');
                        $('#province_type').val(0);
                        $('#city_input_' + cityTargetArea).val('');
                        $('input[name="everycity"]').each(function() {
                            $(this).prop("checked", false);

                            $(this).siblings('a').attr("onclick", "getcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                        }).hide();
                    }
                });

                //选择多个市的控制开关
                $('input[name="manycitys"]').click(function() {
                    //设置省份为单选模式
                    $('#province_type').val(0);
                    $('#city_input_' + cityTargetArea).val('');
                    //开启区县多选
                    if ($(this).prop("checked")) {
                        //设置城市为多选模式标识
                        $('#city_type').val(1);
                        $('input[name="everycity_2"]').each(function() {
                            $(this).click(function() {
                                var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                                if ($(this).prop("checked")) {
                                    if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                        $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                                    }
                                } else {
                                    if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                        $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));

                                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                                    }
                                }
                            });
                        }).show();
                        $('.p_area_2').removeAttr("onclick");
                    } else {
                        $('#citybtn_' + cityTargetArea).val($('.p_c_toggle_' + cityTargetArea + ' li:eq(0)').attr('title'));
                        //设置城市为单选模式
                        $('#city_type').val(0);
                        //置空所有选择
                        $('#city_input_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).attr('data'));
                        $('input[name="everycity_2"]').each(function() {
                            $(this).prop("checked", false);

                            $(this).siblings('a').attr("onclick", "setcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                        }).hide();
                    }
                });
                /*********服务区域多选控制 结束*****/
                
                /*城市选择相关操作的js  结束*/

                $('#submit_btn').click(function(){
                    $.ajax({
                        url: nsTools.apiUrl + '/admin/org/' + org_id,
                        type: 'PUT',
                        data: $('#js_org_form').serialize() + '&atoken=' + atoken
                    })
                    .then(function(){
                        return $.ajax({
                            url: nsTools.apiUrl + '/admin/product/' + product.id,
                            type: 'PUT',
                            data: $('#product_form').serialize() + '&atoken=' + atoken
                        })
                    })
                    .then(function(){
                        location.href = '/fjs/org_list';
                    })
                    .fail(function(jqXHR, textStatus, err){
                        alert(jqXHR.responseText);
                    })
                });
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        })
        .fail(function(jqXHR, textStatus, err){
            alert(jqXHR.responseText);
        });

        function initUpload(){
            nsTools.uploadifyAdmin({
                inputId: '#logo_upload',
                height: 40,
                width: 100,
                onDialogOpen: function(){
                    //清空图片显示区域
                    $('.js_logo').text('');
                },
                onUploadSuccess: function(file, data, response){
                    data = JSON.parse(data);

                    $('.js_logo').append('<img src="' + nsTools.imgServer 
                        + data.imgurl +'" width="100" height="100" />')
                    $('#logo').val(data.imgurl);
                }
            });
        }
    };

    return ns;
}();