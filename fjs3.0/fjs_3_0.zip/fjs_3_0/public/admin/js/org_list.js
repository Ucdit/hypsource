var nsOrgList = function(){
    var ns = {};

    ns.listener = function(){
        // 需求类型按钮
        $('.js-type').click(function(event) {
            /* Act on the event */
            type = $(event.target).data('type');
            var text = $(event.target).text();
            $("#type").text(text);
            searchOrg('1');
        });
        // 需求状态
        $('.js-status').click(function(event) {
            /* Act on the event */
            status = $(event.target).data('status');
            var text = $(event.target).text();
            $("#status").text(text);
            searchOrg('1');
        });
        var isPaginationCreated = false;

        searchOrg('1');

        var type = '';
        var status = '';
        
        function searchOrg(page){
            var url = '';
            if (status) {
                url += '&status=' + status;
            };
            if (type) {
                url += '&type=' + type;
            };
            $.ajax({
                url: nsTools.apiUrl + '/admin/org/search?atoken=' 
                    + nsTools.getCookie('atoken') + '&page=' + page+url,
                type: 'GET'
            })
            .then(function(data){
                c(data)
                $('#js_org_list').text('');
                $("#js_org_list_template").tmpl(data.rows).appendTo('#js_org_list');

                if(!isPaginationCreated){
                    var totalPages = Math.ceil(data.count/10);
                    nsTools.pagination('pagination',totalPages,searchOrg);
                    isPaginationCreated = true;
                }

                $('.js_status_select').change(function(){
                    $.ajax({
                        url: nsTools.apiUrl + '/admin/org/' + $(this).attr('data-org-id'),
                        type: 'PUT',
                        data: {
                            status: $(this).val(),
                            atoken: nsTools.getCookie('atoken')
                        }
                    })
                    .then(function(data){
                        searchOrg(page);
                    })
                    .fail(function(jqXHR, textStatus, err){
                        alert(jqXHR.responseText);
                    });
                });
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    };

    return ns;
}();