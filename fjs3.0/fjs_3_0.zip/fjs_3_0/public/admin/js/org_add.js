var nsOrgAdd = function(){
    var ns = {};

    ns.listener = function(){
        //机构是否存在
        var atoken = nsTools.getCookie('atoken');

        $('#name').autocomplete({
            serviceUrl: nsTools.apiUrl + '/admin/org_name_list',
            onSelect: autocompleteSelectEvent
        })

        //初始化上传组件
        nsTools.createUploadInput('#js_logo_input', '.js_logo', '#logo');

        //表单验证事件
        $('#js_org_form').validate()

        //注册表单提交事件
        addSubmitHandler();

        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'productcity';  
        var cityTargetArea = 'targetAreacity';

        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var cityTargetArea_tmplId = 'city-list_' + cityTargetArea;
        var cityTargetArea_appendTo = '.regions-page1_' + cityTargetArea;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;
        appendTo[cityTargetArea_tmplId] = cityTargetArea_appendTo;

        //省份赋值
        nsTools.getProvince([cityIndex_tmplId, cityTargetArea_tmplId], appendTo);

        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        //业务地域城市选择 (多选)
        $('#citybtn_' + cityTargetArea).click(function(){
           $('.detail-location-picker_' + cityTargetArea).toggle();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });

        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });



        /*********服务区域多选控制 开始 ********/
        $('.p_c_toggle_' + cityTargetArea + ' li').click(function() {
            $("#manyprovinces_span").show();
            $('#city_input_' + cityTargetArea).val('');
            $("#manycitys_span").hide();
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityTargetArea + ' li').remove();
                $('.p_c_toggle_' + cityTargetArea + ' li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityTargetArea).show();
            }
        });

        //选择多个省份的控制开关
        $('input[name="manyprovinces"]').click(function() {
            //开启省份多选模式
            if ($(this).prop("checked")) {
                $('#city_input_' + cityTargetArea).val('');
                $('#citybtn_' + cityTargetArea).val('请选择地区');
                //设置省份模式标识
                $('#province_type').val(1);
                $('#city_type').val(0);
                $('input[name="everycity"]').each(function() {
                    $(this).click(function() {
                        var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                        if ($(this).prop("checked")) {
                            if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                            }
                        } else {
                            if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));
                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                            }
                        }
                    });
                }).show();
                $('.p_area').removeAttr("onclick");
            } else {
                $('#citybtn_' + cityTargetArea).val('请选择地区');
                $('#province_type').val(0);
                $('#city_input_' + cityTargetArea).val('');
                $('input[name="everycity"]').each(function() {
                    $(this).prop("checked", false);

                    $(this).siblings('a').attr("onclick", "getcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                }).hide();
            }
        });

        //选择多个市的控制开关
        $('input[name="manycitys"]').click(function() {
            //设置省份为单选模式
            $('#province_type').val(0);
            $('#city_input_' + cityTargetArea).val('');
            //开启区县多选
            if ($(this).prop("checked")) {
                //设置城市为多选模式标识
                $('#city_type').val(1);
                $('input[name="everycity_2"]').each(function() {
                    $(this).click(function() {
                        var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                        $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                        if ($(this).prop("checked")) {
                            if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                            }
                        } else {
                            if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));

                                $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                            }
                        }
                    });
                }).show();
                $('.p_area_2').removeAttr("onclick");
            } else {
                $('#citybtn_' + cityTargetArea).val($('.p_c_toggle_' + cityTargetArea + ' li:eq(0)').attr('title'));
                //设置城市为单选模式
                $('#city_type').val(0);
                //置空所有选择
                $('#city_input_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).attr('data'));
                $('input[name="everycity_2"]').each(function() {
                    $(this).prop("checked", false);

                    $(this).siblings('a').attr("onclick", "setcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                }).hide();
            }
        });
        /*********服务区域多选控制 结束*****/
        
        /*城市选择相关操作的js  结束*/


        function autocompleteSelectEvent(suggestion){
            $.layer({
                shade: [0.5, '#000'],
                area: ['auto','auto'],
                dialog: {
                    msg: '机构[ ' + $('#name').val() + ' ]已经存在',
                    btns: 2,                    
                    type: 4,
                    btn: ['确定','取消'],
                    yes: function(){
                        $('#name').val('');
                        layer.msg('确定', 1, 1);
                        location.href = '/fjs/org_list'
                    }, no: function(){
                        $('input[name="org_name"]').val('');
                        $('input[name="org_department"]').val('');
                    }
                }
            });
        }

        function addSubmitHandler(){
            $('#btn_submit').click(function(){
                var validForm = true;

                if(!$('#js_org_form').valid()){
                    validForm = false;
                }

                validateProductForm();

                if(validForm){
                    $.ajax({
                        url: nsTools.apiUrl + '/admin/org',
                        type: 'POST',
                        data: $('#js_org_form').serialize() + '&atoken=' + atoken
                    })
                    .then(function(data){
                        addProduct(data.org.id);
                        console.log(data);
                    })
                    .fail(function(jqXHR, textStatus, err){
                        alert(jqXHR.responseText);
                    });
                }

                function validateProductForm(){
                    if(!$('#product_form').valid()){
                        validForm = false;
                    }

                    if($('.checkbox_item input:checked').length !== 3){
                        validForm = false;
                        alert('必须选择三项产品特点');
                    }
                }
            }); 
        }

        function addProduct(org_id){
            $.ajax({
                url: nsTools.apiUrl + '/admin/product',
                type: 'post',
                data: $('#product_form').serialize() + '&atoken=' + atoken
                    + '&org_id=' + org_id
            })
            .then(function(data){
                console.log(data);
                location.href = '/fjs/org_list';
            })
            .fail(function(jqXHR, textStatus, err){
                alert(jqXHR.responseText);
            });
        }
    }

    return ns;
}();