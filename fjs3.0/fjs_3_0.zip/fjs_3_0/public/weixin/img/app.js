'use strict';
require.config({
  paths: {
    'zepto': '/fang/bower_components/zepto/zepto',
    'util': '/fang/bower_components/wechat-util/index',
    // 'WeixinApi':'/fang/wx/weixinApi'
  },
  shim:{
    'zepto':{'exports':'$'}
  }
});
    // 'zepto': '/change/fang/bower_components/zepto/zepto',
    // 'util': '/change/fang/bower_components/wechat-util/index',
define(function(require) {
  // require('WeixinApi')
  require('./slider/anim');
  var App = require('./index.js');
  return new App();
});

