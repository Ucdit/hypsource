var nsUcManager = function(){
    var ns = {};

    ns.listener = function(){

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            //资金方
            $('.zhiwu_title').text(data.last_name + data.title);
            $('.name').text('姓名: ' + data.last_name + data.first_name);
            $('.phone400').text('400绑定电话: 4008102999-' + data.phone400);
            if (data.person_trait) {
                $('.introduction').text('个人简介:' + nsTools.getPersonFeatureCn(data.person_trait));
            }
            if (data.face_image && data.face_image !== '/images/face.png' ) {
                $('.user_img').find('img').attr('src', nsTools.imgServer + data.face_image);
            }

            if (data.status === 3) {
                $('.zhiwu_status').html('<img src="/images/vip.png" />');
                $('.auth_img').attr('src', '/images/right.png');
                $('.name_auth').text('已认证');
                $('.to_auth').html('');
            }

            $('.phone_number').text('(' + nsTools.hidePhone(data.phone) + ')');
            
        }, function() {
            //未登录
            return location.href = '/login';
        });


    }

    return ns;
}();

nsTools.addListener('nsUcManager',nsUcManager.listener);