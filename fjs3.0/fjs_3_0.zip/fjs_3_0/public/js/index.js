var nsIndex = (function() {
    var ns = {};
    ns.listener = function() {
        /*
            需要从表单获取的字段
            发送短信-》注册用户-》提交房产-》提交需求
            类后缀为a是房产抵押贷
            后缀为b是其他需求类型
         */
        // 如果为true，则需要注册再发布
        var needRegister = true;
        // 根据登录状态改变表单
        nsTools.ifLogExecute(function(data) {
            auto_input(data);
        },function(data) {
            auto_input(data);
            $('.js_oneClick').on('click',function() {
                alert('资金方用户不能发布房产需求');
                return false;
            });
        });

        //banner轮播
        $(".lunbo_wrap").innerfade({
            speed: 750, //速度750毫秒
            timeout: 5000, //没2秒变换一次
            containerheight: "1em" //显示的高度为1em
        });
        
        function auto_input(data) {
            // 填写两个表单手机号并禁用
            $('.input_phone_a').val(data.phone).prop('disabled',true)
            .css('background','#eee');
            $('.input_phone_b').val(data.phone).prop('disabled',true)
            .css('background','#eee');
            // 填写两个表单姓名并禁用
            $('.input_last_name_a').val(data.last_name).prop('disabled',true)
            .css('background','#eee');
            $('.input_last_name_b').val(data.last_name).prop('disabled',true)
            .css('background','#eee');
            needRegister = false;
            $('.register_wrap div.horizontal').css('margin-top',34);
        }

        // 房产抵押贷验证
        var newUser_a = {
            phone : 'input_phone_a',
            last_name : 'input_last_name_a',
            type : 'input_user_type_a',
            sms_code : 'input_sms_code_a',
        },
        newRealestate_a = {
            city : 'input_city_a',
            name : 'input_name_a',
            worth : 'input_worth_a',
        },
        newNeed_a = {
            amount_money : 'input_amount_money_a',
            type : 'input_need_type_a',
        };

        var realestate_id;
        var need_id;
        var layer_More;
        $('.js_mortgage_form').validate({
            // 验证规则及验证话术
            rules : RULE.index.mortgage_rule,
            messages : RULE.index.mortgage_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var newUser_back_a = nsTools.fetchInput(newUser_a);
                var newRealestate_back_a = nsTools.fetchInput(newRealestate_a);
                var newNeed_back_a = nsTools.fetchInput(newNeed_a);
                /*
                    如果已经登录，则直接发布房产和需求
                 */
                if (needRegister) {
                    nsTools.ajax('post','/user',newUser_back_a)
                    .then(function(data) {
                        newRealestate_back_a.user_id = data.user.id;
                        newNeed_back_a.user_id = data.user.id;
                        return nsTools.ajax('post','/realestate',newRealestate_back_a);
                    },function(data){
                        nsTools.trans400(data,2,'电话已注册，请登录');
                    })
                    .then(function(data) {
                        newNeed_back_a.realestate_id = data.realestate_id;
                        realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/need',newNeed_back_a);
                    })
                    .then(function(data) {
                        need_id = data.realestate_need_id;
                        layer_More = nsTools.layer('js_form_two');
                        nsTools.baidu_tongji('statistic_regandsub');
                        update();
                    })
                }else{
                    newRealestate_back_a.user_id = nsTools.dataTmp.id;
                    newNeed_back_a.user_id = nsTools.dataTmp.id;
                    nsTools.ajax('post','/realestate',newRealestate_back_a)
                    .then(function(data) {
                        newNeed_back_a.realestate_id = data.realestate_id;
                        realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/need',newNeed_back_a);
                    })
                    .then(function(data) {
                        need_id = data.realestate_need_id;
                        layer_More = nsTools.layer('js_form_two');
                        nsTools.baidu_tongji('statistic_later_sub');
                        update();
                    })
                };
                
            }
        });

        // 第二个表单更新房产信息和需求信息
        function update() {
            var need_up = {
                interest : 'input_interest',
                debt_duration : 'input_debt_duration'
            }
            var real_up = {
                type : 'input_type',
                house_num : 'input_house_num',
                builder : 'input_builder',
                age : 'input_age',
                is_mortgaged : 'input_is_mortgaged'
            }

            $('.js_form_more').validate({
                // 验证规则及验证话术
                rules : RULE.product_detail.product_rule,
                messages : RULE.product_detail.product_messages,
                // 成功处理
                submitHandler: function(form) {
                    $('.js_more').trigger('clickFade');
                    need_up_back = nsTools.fetchInput(need_up);
                    real_up_back = nsTools.fetchInput(real_up);
                    // 更新房产
                    nsTools.ajax('put','/realestate/'+realestate_id,real_up_back)
                    .then(function(data) {
                        return nsTools.ajax('put','/need/'+need_id,need_up_back)
                    })
                    .then(function(data){
                        layer.close(layer_More);
                        nsTools.layer('js_form_three');
                    })
                }
            });
        }
        // 其他需求类型表单验证
        var newUser_b = {
            phone : 'input_phone_b',
            last_name : 'input_last_name_b',
            type : 'input_user_type_b',
            sms_code : 'input_sms_code_b',
        },
        newRealestate_b = {
            city : 'input_city_b',
            name : 'input_name_b',
            worth : 'input_worth_b',
        },
        newNeed_b = {
            type : 'input_need_type_b',
        };
        $('.js_other_form').validate({
            // 验证规则及验证话术
            rules : RULE.index.other_rule,
            messages : RULE.index.other_messages,
            // errorLabelContainer : $('#error_b'),
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var newUser_back_b = nsTools.fetchInput(newUser_b);
                var newRealestate_back_b = nsTools.fetchInput(newRealestate_b);
                var newNeed_back_b = nsTools.fetchInput(newNeed_b);
                /*
                    注册用户-》发布房产-》发布需求
                    如果已经登录，则直接发布房产和需求
                 */
                if (needRegister) {
                    nsTools.ajax('post','/user',newUser_back_b)
                    .then(function(data) {
                        newRealestate_back_b.user_id = data.user.id;
                        newNeed_back_b.user_id = data.user.id;
                        return nsTools.ajax('post','/realestate',newRealestate_back_b);
                    })
                    .then(function(data) {
                        newNeed_back_b.realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/other_need',newNeed_back_b);
                    })
                    .then(function(data) {
                        nsTools.baidu_tongji('statistic_regandsub');
                        nsTools.layerStop('恭喜您发布成功，我们的顾问会通过4008102999电话联系您。',function(){
                            location.href="/";
                        })
                    })
                }else{
                    newRealestate_back_b.user_id = nsTools.dataTmp.id;
                    newNeed_back_b.user_id = nsTools.dataTmp.id;
                    nsTools.ajax('post','/realestate',newRealestate_back_b)
                    .then(function(data) {
                        newNeed_back_b.realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/other_need',newNeed_back_b);
                    })
                    .then(function(data) {
                        nsTools.baidu_tongji('statistic_later_sub');
                        nsTools.layerStop('恭喜您发布成功，我们的顾问会通过4008102999电话联系您。',function(){
                            location.href="/";
                        })
                    })
                };
                
            }
        });
        // 渲染推荐产品-房产抵押贷
        nsTools.ajax('GET','/hot_product','?type=1')
        .then(function(data) {
            $('#self_use_lists').tmpl(data.slice(0,4)).appendTo($('.self_use_lists'));
            $('.recommend_wrap .list').eq(3).css('border','none');
        })
        //渲染最新融资房产
        nsTools.ajax('get','/need/search','?type=1')
        .then(function(data) {
            var data = data.rows;
            $('#new-reallist').tmpl(data.slice(0,4)).appendTo($('.new-reallist'));
        });
        //渲染最新房抵产品
        nsTools.ajax('get','/product/search','')
        .then(function(data) {
            var data = data.rows;
            $('#new-manglist').tmpl(data.slice(0,4)).appendTo($('.new-manglist'));
        });

        // 渲染最新成功对接1
        nsTools.ajax('GET','/duijie','')
        .then(function(data) {
            $('#new_list_1').tmpl(data.slice(0,2)).appendTo($('.new_list_1'));
        })
        // 渲染最新成功对接2
        nsTools.ajax('GET','/duijie','')
        .then(function(data) {
            $('#new_list_2').tmpl(data.slice(2,4)).appendTo($('.new_list_2'));
        })
        // 渲染最新成功对接3
        nsTools.ajax('GET','/duijie','')
        .then(function(data) {
            $('#new_list_3').tmpl(data.slice(4,6)).appendTo($('.new_list_3'));
            // 最新对接轮播
            $('#js_newContact').bxSlider({
                auto: true,
                pause:8000,
                auto_controls: true,
                nextSelector : '.go_right',
                prevSelector : '.go_left',
                nextText : '.',
                prevText : '.'
            });
        })

        // 渲染推荐产品
        nsTools.ajax('get','/hot_product','?type=1&limit=4')
        .then(function(data) {
            $('#info_wrap').tmpl(data).appendTo($('.info_wrap'));
        });
        

            
        // 绑定发送发送验证码事件
        nsTools.sendSms('js_sendSms_a',$('.input_phone_a'));
        nsTools.sendSms('js_sendSms_b',$('.input_phone_b'));
        // 防止多次提交
        nsTools.oneClick('申请中','js_a');
        nsTools.oneClick('申请中','js_b');
        nsTools.oneClick('申请中','js_more');
        // 注册表单切换
        nsTools.tabChange('js_mortgage_li','js_mortgage_block','active');
        nsTools.tabChange('js_pro_li','js_pro_block','active');
        // 如果有城市则填写城市
        nsTools.autoPutCity('#city_input_indexcity','#citybtn_indexcity');
        nsTools.autoPutCity('#city_input_usehousecity','#citybtn_usehousecity');


        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'indexcity';
        var cityHouseUse = 'usehousecity';  
        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var cityHouseUse_tmplId   = 'city-list_' + cityHouseUse;
        var cityHouseUse_appendTo = '.regions-page1_' + cityHouseUse;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;
        appendTo[cityHouseUse_tmplId] = cityHouseUse_appendTo;

        nsTools.getProvince([cityIndex_tmplId, cityHouseUse_tmplId], appendTo);

        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });

        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });
        
        //以房类城市选择的显示与隐藏
        $('#citybtn_' + cityHouseUse).click(function(){
            $('.detail-location-picker_' + cityHouseUse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouseUse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouseUse).show();   
            }
        });

        //以房类选择全部
        $('.allcity_' + cityHouseUse).click(function(){
            $('#city_input_' + cityHouseUse).val($('#citybtn_' + cityHouseUse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouseUse).val($('#citybtn_' + cityHouseUse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouseUse + ' li:eq(0)').click();
            $('.close_' + cityHouseUse).click();
        });

        // 点击默认页面其余位置关闭城市选择
        $(document).click(function(e){
           var cityDiv_indexcity = $('.detail-location-picker_indexcity')[0];
           var target = e.target;
           var citybtn_indexcity = $('.btn')[0];

           if (cityDiv_indexcity !== target && !$.contains(cityDiv_indexcity, target) && citybtn_indexcity !== target) 
           {
              $('.detail-location-picker_indexcity').hide();
           }

           //以房类
           var cityDiv_usehousecity = $('.detail-location-picker_usehousecity')[0];
           var target = e.target;
           var citybtn_usehousecity = $('.btn')[1];

           if (cityDiv_usehousecity !== target && !$.contains(cityDiv_usehousecity, target) && citybtn_usehousecity !== target) 
           {
              $('.detail-location-picker_usehousecity').hide();
           }

        });


        /*城市选择相关操作的js  结束*/


    }
    return ns;
}());
nsTools.addListener('nsIndex',nsIndex.listener);