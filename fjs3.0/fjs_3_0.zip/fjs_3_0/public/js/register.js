var nsRegister = (function() {
    var ns = {};
    ns.listener = function() {
    	/*
    		n后缀的为普通用户注册，
    		m后缀为信贷经理注册。
    	 */
        // 如果已经登录则跳转回首页
        nsTools.ifLogExecute(function(data){
            window.location.href="/"
        },function(){
            window.location.href="/"
        })
    	
    	// 普通用户注册
    	var user_n = {
    		last_name : 'input_last_name_n',
    		type : 'input_user_type_n',
    		phone : 'input_phone_n',
    		sms_code : 'input_sms_code_n',
    		password : 'input_password_n',
            gender : 'input_gender_n',
    	};
    	$('.js_reg_normal').validate({
            // 验证规则及验证话术
            rules : RULE.register.nReg_rule,
            messages : RULE.register.nReg_messages,
            errorLabelContainer : $('#error_n'),
            // 成功处理
            submitHandler: function(form) {
            	if($('.js_read_n').prop('checked')===false) {
            		alert('请同意《房金所服务条款》');
            		return false;
            	}

                $('.js_n').trigger('clickFade');
                // 获取相应表单值
                user_n_back = nsTools.fetchInput(user_n);
                nsTools.ajax('post','/user/register_with_password',user_n_back)
                .then(function(data) {
                    console.log(data);
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.layerStop("恭喜您注册成功",function(){
                        location.href="/";
                    });
                    
                })
            }
        });
        // 信贷经理注册
        var user_m = {
    		last_name : 'input_last_name_m',
    		type : 'input_user_type_m',
    		phone : 'input_phone_m',
    		sms_code : 'input_sms_code_m',
    		password : 'input_password_m',
            gender : 'input_gender_m'
    	};
    	$('.js_reg_manager').validate({
            // 验证规则及验证话术
            rules : RULE.register.mReg_rule,
            messages : RULE.register.mReg_messages,
            errorLabelContainer : $('#error_m'),
            // 成功处理
            submitHandler: function(form) {
            	// 如果没有同意协议，则不让提交
            	if($('.js_read_m').prop('checked')===false) {
            		alert('请同意《房金所服务条款》');
            		return false;
            	}

            	$('.js_m').trigger('clickFade');
                // 获取相应表单值
                user_m_back = nsTools.fetchInput(user_m);
                nsTools.ajax('post','/user/register_with_password',user_m_back)
                .then(function(data) {
                    console.log(data);
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.layerStop("注册成功",function(){
                        location.href="/";
                    });
                })
            }
        });
    	// 发送验证码
    	nsTools.sendSms('js_sendSms_n',$('.input_phone_n'));
    	nsTools.sendSms('js_sendSms_m',$('.input_phone_m'));
    	// 防止多次提交
        nsTools.oneClick('正在注册中','js_n');
        nsTools.oneClick('正在注册中','js_m');
        // 注册表单切换
        nsTools.tabChange('js_reg_li','js_reg_block','active');
        // 根据身份选择tab
        var roleType = window.location.search.slice(-1);
        if (roleType==2) {
           $('.js_reg_li')[1].click();
        };
	}
    return ns;
}());
nsTools.addListener('nsRegister',nsRegister.listener);
