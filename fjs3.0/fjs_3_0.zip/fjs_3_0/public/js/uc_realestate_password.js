var nsRealestatePassword = (function() {
    var ns = {};
    ns.listener = function() 
    {
        nsTools.ifLogExecute(function(data) {
            $('.js_changePass').validate({
                // 验证规则及验证话术
                rules: {
                    password_new_1: {
                        required: true,
                        minlength: 6,
                    },

                    password_new_2: {
                        required: true,
                        minlength: 6,
                        equalTo: "#password",
                    },
                },
                messages: {
                    password_new_1: {
                        required: '不能为空',
                        minlength: '密码长度至少6位',
                    },
                    password_new_2: {
                        required: '不能为空',
                        minlength: '密码长度至少6位',
                        equalTo: '两次输入密码不一致',
                    },
                },
                // 成功处理
                submitHandler: function(form) {
                    var password = $('.password_new_2').val();
                    var userId = nsTools.getCookie('userId');
                    var token = nsTools.getCookie('token');

                    var user_m = {
                        user_id: userId,
                        password: password,
                        token: token
                    };

                    nsTools.ajax('post', '/set_password', user_m)
                        .then(function(data) {
                            $.layer({
                                title: '提示',
                                time: 2,
                                dialog: {
                                    type: 1,
                                    msg: '操作成功！'
                                },
                                area: ['auto', 'auto'],
                                btns: 1,
                                btn: ['确定'],
                                end: function() {
                                    location.reload();
                                }
                            });

                        })
                }
            });
        },
        function(data) {
            return location.href = '/uc/manager';
        },
        function() {
            return location.href = '/login'
        });
	}

    return ns;
}());

nsTools.addListener('nsRealestatePassword',nsRealestatePassword.listener);
