var nsUcManagerApply = function(){
    var ns = {};

    ns.listener = function(){
        var token = nsTools.getCookie('token');

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            //资金方
            nsTools.ajax('get','/apply/search', '?user_id=' + data.id)
            .then(function(data) {
                $('#apply-tmp').tmpl(data).appendTo($('.tb'));
            });
            
        }, function() {
            //未登录
            return location.href = '/login';
        });
    };

    ns.setStatus = function(sta, apply_id){
        var msgstr = '您确定要执行该操作吗?';
        if (sta === '2') {
            msgstr = '您需要将该申请设置为[对接成功]状态吗?'
        } else if (sta === '-1') {
            msgstr = '您需要将该申请设置为[对接失败]状态吗?'
        }
        $.layer({
            shade: [0.5, '#000'],
            area: ['auto', 'auto'],
            dialog: {
                msg: msgstr,
                btns: 2,
                type: 4,
                btn: ['确定', '取消'],
                yes: function() {
                    nsTools.ajax('put', '/apply/' + apply_id, {status : sta})
                    .then(function(data){
                        $.layer({
                            title: '提示',
                            time: 2,
                            dialog: {
                                type: 1,
                                msg: '操作成功'
                            },
                            area: ['auto', 'auto'],
                            btns: 1,
                            btn: ['确定'],
                            end: function() {
                                location.reload();
                            }
                        });                        
                    });

                },
                no: function() {
                    location.reload();
                }
            }
        });
        
    };

    return ns;
}();
nsTools.addListener('nsUcManagerApply', nsUcManagerApply.listener);