var nsSearch = (function() {
    var ns = {};
    ns.listener = function() {
        var searchFilter = {};
        var second_bet = '';

        var amount_money = parseInt($.url('?amount_money', location.href)) || '';
        var debt_duration = parseInt($.url('?debt_duration', location.href)) || '';
        var interest = parseInt($.url('?interest', location.href)) || '';
        var org_type = parseInt($.url('?org_type', location.href)) || '';
        // 跳转过来填写
        $('input[name=amount_money]').val(amount_money);
        $('input[name=debt_duration]').val(debt_duration);
        $('input[name=interest]').val(interest);
        // 跳转过来自动选择
        if (org_type) {
            $('.search_ipt option').eq(org_type).prop('selected',true)
        };
        searchFilter = {
            // second_bet: 1,
            // only_one_house: 1,
            debt_duration : debt_duration,
            amount_money : amount_money,
            interest: interest,
            page: 1 ,
            org_type : org_type,
        };

        var flag = true;  //没有任何条件则执行默认搜索

        $('#search_btn').click(function(){
            getFilterCondition();
            searhPost(searchFilter);
        });

    	//房产类型
        $('#realestate_type_filter_type').find('li').click(function(){
        	$('.filter_item').text($(this).text());
            if ($(this).text() === '住宅')
            {
                searchFilter.pledge_house = 1;
                searchFilter.pledge_office = null;
                searchFilter.pledge_shop = null;
                searchFilter.pledge_small_property_house = null;
                searchFilter.pledge_factory = null;
            } else if ($(this).text() === '办公') {
                searchFilter.pledge_office = 1;
                searchFilter.pledge_house = null;
                searchFilter.pledge_shop = null;
                searchFilter.pledge_small_property_house = null;
                searchFilter.pledge_factory = null;
            } else if ($(this).text() === '商铺') {
                searchFilter.pledge_shop = 1;
                searchFilter.pledge_house = null;
                searchFilter.pledge_office = null;
                searchFilter.pledge_small_property_house = null;
                searchFilter.pledge_factory = null;
            } else if ($(this).text() === '小产权房') {
                searchFilter.pledge_small_property_house = 1;
                searchFilter.pledge_house = null;
                searchFilter.pledge_office = null;
                searchFilter.pledge_shop = null;
                searchFilter.pledge_factory = null;            
            } else if ($(this).text() === '厂房') {
                searchFilter.pledge_factory = 1;
                searchFilter.pledge_house = null;
                searchFilter.pledge_office = null;
                searchFilter.pledge_shop = null;
                searchFilter.pledge_small_property_house = null;
            } else {
                searchFilter.pledge_house = null;
                searchFilter.pledge_office = null;
                searchFilter.pledge_shop = null;
                searchFilter.pledge_small_property_house = null;
                searchFilter.pledge_factory = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        	$('.realestates_type').show();
        	$('.clear_all_filter').show();
        	$(this).addClass("li_on").siblings('li').removeClass('li_on');
            $('input[name="realestate_type"]').val($(this).attr('v'));
        });

        $('.filter_close').click(function(){
        	$('.realestates_type').hide();
            $('input[name="realestate_type"]').val('');
            searchFilter.pledge_house = null;
            searchFilter.pledge_office = null;
            searchFilter.pledge_shop = null;
            searchFilter.pledge_small_property_house = null;
            searchFilter.pledge_factory = null;
            getFilterCondition();
            searhPost(searchFilter);
            $('#realestate_type_filter_type').find('li').removeClass('li_on');
            if ($('.one_house_type').is(':hidden') && $('.mortgage_type').is(':hidden'))
            {
                $('.clear_all_filter').hide();
            }
        });

        //一套房
        $('#one_house_filter_type').find('li').click(function(){
        	$('.one_house_filter_item').text($(this).text());
            if ($(this).text() === '受理')
            {
                searchFilter.only_one_house = 1;
            } else if ($(this).text() === '不受理') {
                searchFilter.only_one_house = -1;
            } else {
                searchFilter.only_one_house = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        	$('.one_house_type').show();
        	$('.clear_all_filter').show();
        	$(this).addClass("li_on").siblings('li').removeClass('li_on');
        });

        $('.one_house_filter_close').click(function(){
            searchFilter.only_one_house = null;
            getFilterCondition();
            searhPost(searchFilter);
            $('#one_house_filter_type').find('li').removeClass('li_on');
        	$('.one_house_type').hide();
            if ($('.realestates_type').is(':hidden') && $('.mortgage_type').is(':hidden'))
            {
                $('.clear_all_filter').hide();
            }
        });

        //二押
        $('#mortgage_filter_type').find('li').click(function(){
            if ($(this).text() === '受理')
            {
                searchFilter.second_bet = 1;
            } else if ($(this).text() === '不受理') {
                searchFilter.second_bet = -1;
            } else {
                searchFilter.second_bet = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        	$('.mortgage_filter_item').text($(this).text());
        	$('.mortgage_type').show();
        	$('.clear_all_filter').show();
        	$(this).addClass("li_on").siblings('li').removeClass('li_on');

        });

        $('.mortgage_filter_close').click(function(){
            searchFilter.second_bet = null;
            getFilterCondition();
            searhPost(searchFilter);
            $('#mortgage_filter_type').find('li').removeClass('li_on');
        	$('.mortgage_type').hide();
            if ($('.realestates_type').is(':hidden') && $('.one_house_type').is(':hidden'))
            {
                $('.clear_all_filter').hide();
            }
        });

        //清除所有条件
        $('.clear_all_filter').click(function(){
            searchFilter.only_one_house = null;
            searchFilter.second_bet = null;
            searchFilter.pledge_house = null;
            searchFilter.pledge_office = null;
            searchFilter.pledge_shop = null;
            searchFilter.pledge_small_property_house = null;
            searchFilter.pledge_factory = null;
            getFilterCondition();
            searhPost(searchFilter);
        	$('.realestates_type').hide();
        	$('.one_house_type').hide();
        	$('.mortgage_type').hide();
        	$('#realestate_type_filter_type').find('li').removeClass('li_on');
        	$('#one_house_filter_type').find('li').removeClass('li_on');
        	$('#mortgage_filter_type').find('li').removeClass('li_on');
        	$(this).hide();
        });

        $('input[name="credit"]').click(function(){
            if ($(this).is(':checked'))
            {
                searchFilter.material_credit = 1;
            } else {
                searchFilter.material_credit = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        });

        $('input[name="stream"]').click(function(){
            if ($(this).is(':checked'))
            {
                searchFilter.material_stream = 1;
            } else {
                searchFilter.material_stream = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        });

        $('input[name="purpose"]').click(function(){
            if ($(this).is(':checked'))
            {
                searchFilter.material_purpose = 1;
            } else {
                searchFilter.material_purpose = null;
            }
            getFilterCondition();
            searhPost(searchFilter);
        });

        $('select[name="org_type"]').change(function(){
            getFilterCondition();
            searhPost(searchFilter);
        });

        //获取筛选条件
        function getFilterCondition()
        {
            flag = false;
            searchFilter.page = 1;
            searchFilter.amount_money = $('input[name="amount_money"]').val();
            searchFilter.interest = $('input[name="interest"]').val();
            searchFilter.debt_duration = $('input[name="debt_duration"]').val();
            searchFilter.promise_duration = $('input[name="promise_duration"]').val();
            searchFilter.org_type = $('select[name="org_type"]').val();
        }
        
        //搜索
        function searhPost(searchFilter)
        {
            $.ajax({
                url: nsTools.apiUrl + '/product/search',
                type:'get',
                data: searchFilter,
                success:function(data){
                    var pageHtml = '<div class="search_page_position"><ul>';
                    var pageSize = 10;
                    $('.search_page_digits').text(data.count);
                    for (var i=1; i < Math.ceil(data.count/pageSize) + 1; i++)
                    {
                        if (searchFilter.page === i)
                        {
                            pageHtml += '<li class="search_page_current" onclick="nsSearch.setPage(' + i + ', ' + Math.ceil(data.count/pageSize) + ')">' + i + '</li>';
                        } else {
                            pageHtml += '<li onclick="nsSearch.setPage(' + i + ', ' + Math.ceil(data.count/pageSize) + ')">' + i + '</li>';
                        }
                        
                    }
                    if (data.count/pageSize > 0)
                    {
                        pageHtml += ' <li class="search_next_page" onclick="nsSearch.setPage(' + (searchFilter.page + 1) + ', ' + Math.ceil(data.count/pageSize) + ')" >下一页</li></ul><span class="search_page_nums">共<span class="search_page_digits">' + data.count + '</span>个结果</span></div>';
                    }
                    $('.search_page').html(pageHtml);
                    $('#data_rs').html('');
                    $("#search-tmp").tmpl(data.rows).appendTo('#data_rs');
                }
            });
        }

        //没有任何条件时执行无条件搜索
        if (flag){
            searhPost(searchFilter);
        }

        ns.setPage = function(i, maxPage){
            if (i > maxPage) i = maxPage;
            if (i)
            {
                getFilterCondition();
                searchFilter.page = i;
                searhPost(searchFilter);
            }
        }

    }
    return ns;
}());

nsTools.addListener('nsSearch',nsSearch.listener);