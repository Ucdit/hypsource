var nsUcManagerCase = function(){
    var ns = {};

    ns.listener = function(){
        var token = nsTools.getCookie('token');

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            //资金方
            //获取需求信息
            nsTools.ajax('get', '/managercase/getcase/' + data.id, '')
            .then(function(cases) {
                console.log(cases)
                var htmlstr = '';
                for (var i in cases.rows)
                {
                    htmlstr += '<tr>'+
                                '<td>' + cases.rows[i].customer_name + '</td>' +
                                '<td>' + cases.rows[i].deal_money + '万元' +'</td>' +
                                '<td>' +1 +'</td>' +
                                '<td>' + 1+ '</td>' +
                                '<td>' + cases.rows[i].debt_duration + '月' + '</td>' +
                                '<td>' + '删除' + '</td>' +
                              '</tr>';
                }
                

                $(htmlstr).appendTo('.tb');
                     
            });
        }, function() {
            //未登录
            return location.href = '/login';
        });
    };

    return ns;
}();
nsTools.addListener('nsUcManagerCase',nsUcManagerCase.listener);