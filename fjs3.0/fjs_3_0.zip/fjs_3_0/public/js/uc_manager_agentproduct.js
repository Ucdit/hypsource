var nsUcManagerAgentProduct = function(){
    var ns = {};

    ns.listener = function(){
        var token = nsTools.getCookie('token');

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            //资金方
            var condition = '';
            condition = '?user_id=' + data.id + '&type=2';
            //获取需求信息
            nsTools.ajax('get', '/managerproduct/getmp', condition)
            .then(function(mp) {
                var htmlstr = '';
                for (var i in mp){
                     htmlstr += '<tr>'+
                                    '<td>' + nsTools.Date_Format(mp[i].created_at, 'yyyy-MM-dd') + '</td>' +
                                    '<td><a style="color:#0099da;"href="/product_detail?id=' + mp[i].Product.id + '" target="_blank">' + mp[i].Product.name +'</a></td>' +
                                    '<td>' + mp[i].Org.name +'</td>' +
                                    '<td>' + nsTools.getProductStatus(mp[i].Org.status) + '</td>' +
                                '</tr>';
                }
                
                $(htmlstr).appendTo('.tb');
                     
            });
        }, function() {
            //未登录
            return location.href = '/login';
        });
    };

    return ns;
}();
nsTools.addListener('nsUcManagerAgentProduct',nsUcManagerAgentProduct.listener);