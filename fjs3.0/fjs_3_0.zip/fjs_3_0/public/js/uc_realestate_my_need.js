var nsRealestateMyNeed = (function() {
    var ns = {};
    ns.listener = function() 
    {
        nsTools.ifLogExecute(function(data) {
            var userId = nsTools.getCookie('userId');

            nsTools.ajax('get', '/user_need/'+ userId, '')
            .then(function(needs) {
                var htmlstr = '';
                for(var i in needs)
                {
                    var tdColor = '';
                    if (i%2 == 0)
                    {
                        tdColor = 'style="background:#fff;"';
                    }

                    htmlstr += '<tr>'+
                                    '<td '+ tdColor +'>' + needs[i].Realestate.name + '</td>' +
                                    '<td '+ tdColor +'>' + nsTools.RealestateNeedType(needs[i].type) +'</td>' +
                                    '<td '+ tdColor +'>' + needs[i].Realestate.code +'</td>' +
                                    '<td '+ tdColor +'>' + nsTools.Date_Format(needs[i].created_at, 'yyyy-MM-dd') + '</td>' +
                                    '<td '+ tdColor +'>' + nsTools.RealestateNeedStatusValue(needs[i].status) +'</td>' ;

                                var opstr = '<td '+ tdColor +'></td>';
                                if (needs[i].status === 2)
                                {
                                    opstr = '<td '+ tdColor +' onclick="nsRealestateMyNeed.closeNeed(4, ' + needs[i].id + ');"><span class="opt">关闭</span></td>';
                                } else if (needs[i].status === 4) {
                                    opstr = '<td '+ tdColor +' onclick="nsRealestateMyNeed.closeNeed(2,' + needs[i].id + ');"><span class="opt">开启</span></td>';
                                } 

                    htmlstr += opstr;
                    htmlstr +=  '</tr>';
                }
                

                $(htmlstr).appendTo('.tb');
                     
            });
        },

        
        function(data) {
            return location.href = '/uc/manager';
        },
        function() {
            return location.href = '/login';
        });
	};

    ns.closeNeed = function(status, need_id){
        var msgstr = '您确定要执行该操作吗?';
        if (status === 2)
        {
            msgstr = '开启后您的需求将被显示在网站上,您确定要[开启]该需求吗?';
        }else if (status === 4){
            msgstr = '关闭后您的需求将被隐藏,您确定要[关闭]该需求吗?';
        }

        $.layer({
            shade: [0.5, '#000'],
            area: ['auto', 'auto'],
            dialog: {
                msg: msgstr,
                btns: 2,
                type: 4,
                btn: ['确定', '取消'],
                yes: function() {
                    nsTools.ajax('put', '/need/' + need_id, {status : status})
                    .then(function(data){
                        $.layer({
                            title: '提示',
                            time: 2,
                            dialog: {
                                type: 1,
                                msg: '操作成功'
                            },
                            area: ['auto', 'auto'],
                            btns: 1,
                            btn: ['确定'],
                            end: function() {
                                location.reload();
                            }
                        });                        
                    });

                },
                no: function() {
                    // location.reload();
                }
            }
        });
        
    };

    return ns;
}());

nsTools.addListener('nsRealestateMyNeed',nsRealestateMyNeed.listener);
