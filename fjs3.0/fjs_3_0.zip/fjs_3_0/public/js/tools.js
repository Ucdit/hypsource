var nsTools = (function(){
    var ns = {};
    var listeners = {};
    // 跨越api端口
    var apiUrl = "/fjsapi";
    ns.apiUrl = apiUrl;

    ns.imgServer = "http://api.fangjinsuo.com:4002";
    ns.imgServer2 = "http://api.fangjinsuo.com:4002";

    ns.addListener = function(name, listener) {
        listeners[name] = listener;
    };

    ns.runStartScript = function(){
        for(var i in listeners){
            listeners[i]();
        }
    };
    // 设置cookie
    ns.setCookie = function(c_name,value,expiredays) {
        var exdate=new Date();
        exdate.setDate(exdate.getDate()+expiredays);
        document.cookie= c_name + "=" + escape(value)
        + ';path=/;' 
        + ((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
    }
    // 取得cookie
    ns.getCookie = function(c_name) {
        if (document.cookie.length>0) {
            var cookies = document.cookie.split(';')
            if(cookies.length > 0){
                for(var i=0; i<cookies.length; i++){
                    var cookieItem = cookies[i].split('=');
                    var key = $.trim(cookieItem[0]);
                    var value = $.trim(cookieItem[1]);
                    if(key === c_name){
                        return unescape(value);
                    }
                }
            }
          // c_start=document.cookie.indexOf(c_name + "=")
          // if (c_start!=-1)
          // { 
          //   c_start=c_start + c_name.length+1 
          //   c_end=document.cookie.indexOf(";",c_start)
          //   if (c_end==-1) c_end=document.cookie.length
          //   return unescape(document.cookie.substring(c_start,c_end))
          // } 
        }
        return "";
    }
    /*
        封装$.ajax
        @param {String} method
        @param {String} url
        @param {Object} data
        eg:nsTools.ajax('post','/sms_code',{name:'bai'})
     */
    ns.ajax = function(method, url, data) {
        var method = method.toLowerCase();
        var callObj = {};
        var self = this;
        var getData, postData;

        if(method == 'get') {
            getData = data+'';
            postData = '';
            // 传入token
            if (getData.indexOf('?')==-1) {
                getData += '?token='+self.getCookie('token');
            }else{
                getData += '&token='+self.getCookie('token');
            };
        }else if(method == 'post' || method == 'put') {
            postData = data;
            getData = '';
            // 传入token
            postData.token = self.getCookie('token');
        }

        callObj = {
            url: apiUrl + url +"/"+getData,
            xhrFields:{
                withCredentials: true
            },
            statusCode: {
                400: function(data) {
                    var data = eval('('+data.responseText+')');
                    alert(data.message);
                    // 伪事件，失败重新激活提交按钮
                    $('.js_oneClick').trigger('againClick');
                },
                500: function() {
                    // window.location.href="500.html";
                }
            },
            type:method,
            data:postData,
        }
        // 如果是登录的用户，则将userId和token存入cookie
        if ( (url == '/sms_login') || (url == '/login') || (url == '/user' || (url == '/user/register_with_password')) ) {
            callObj.success = function(data) {
                self.setCookie('userId',data.user.id);
                self.setCookie('token',data.token);
            }
        }

        return  $.ajax(callObj);
    }

    ns.trans400 = function(data,codeType,alertText) {
        var data = eval('('+data.responseText+')');
        if (data.code==codeType) {
            alert(alertText)
        };
    }

    /*
        点击发送短信验证码并倒计时
        @param buttonClass 
        @param phone string
        eg:nsTools.sendSms('js_sendSms',18621706260);
     */
    ns.sendSms = function(buttonClass, phone ,sms_type) {
        var time = 60;
        var self = this;
        var $sendButton = $('.'+buttonClass);
        var timer;
        var sms_url = '/sms_code';
        if (sms_type==2) {
            sms_url = '/login_sms_code' 
        };
        function setTime() {
            if(time>0) {
                $sendButton.text(time+'秒后可重新获取');
                time--;
            }else{
                clearInterval(timer);
                $sendButton.text('获取验证码')
                .attr('disabled',false);
                time = 60;
            }
        }
        function handlePhone(e) {
            if(phone.val().length<11){
                alert('电话不规范，请重新输入');
                return false;
            }
            e.preventDefault();
            $sendButton.attr('disabled',true);
            self.ajax('post',sms_url,phone)
            .done(function(data) {
                timer = setInterval(setTime,1000);
                // alert(data.sms_code);
            })
        }

        $sendButton.on('click',handlePhone);
    }

    /*
        使得添加js_oneClick类的dom元素能够在成功传输ajax请求的时候无法点击
        @param string 定义提交时候按钮变化的文字
        eg:nsTools.oneClick('提交中...');
     */
    ns.oneClick = function(text,className) {
        var $oneClickButton = $('.'+className);
        var defaultText = $oneClickButton.val();
        $oneClickButton.on('clickFade',function() {
            $oneClickButton.attr('disabled',true).val(text);
        })
        .on('againClick',function() {
            $oneClickButton.attr('disabled',false)
            .val(defaultText);
        })
    }

    /*
        传入{api字段 ：html中类名}返回{api字段 ：input的填入值}
        @param object
        eg:nsTools.fetchInput({phone : 'input_phone'});
     */
    ns.fetchInput = function(list) {
        var submitValue = {};
        for(var i in list){
            if ($('.'+list[i]).length>1) {
                submitValue[i] = $('.'+list[i]+":checked").val();
                continue;
            };
            submitValue[i] = $('.'+list[i]).val();
        }
        return submitValue;
    }
    /*
        tab切换功能
        @param string 切换按钮的类名
        @param string 切换区域块的类名
        @param object 切换按钮的样式
        @param function 回调函数
     */
    ns.tabChange = function(tabLi, contentBlock, tabStyle, cb) {
        var $tab = $('.'+tabLi);
        var $content = $('.'+contentBlock);
        $tab.on('click',function() {
            var indexLi = $(this).index();
            if(tabStyle) $(this).addClass(tabStyle).siblings().removeClass(tabStyle);
            $content.eq(indexLi).show().siblings('.'+contentBlock).hide();
            if(typeof cb =="function") cb();
        })
    }
    /*
        hover以后显示，放开隐藏功能
        @param string 接受动作的dom类名
        @param string 显示隐藏的dom雷鸣
     */
    ns.hoverShow = function(hoverDom,showDom) {
        var $hoverDom = $('.'+hoverDom);
        var $showDom = $('.'+showDom);
        $hoverDom.on('mouseover',function(e) {
            var $target = $(e.target);
            $showDom.show();
        }).on('mouseout',function() {
            $showDom.hide();
        })

    }

    /**
     * 日期格式化函数
     * @param datestr 需要格式的时间
     * @param fmt     格式化的格式
     * 例: Date_format('2014-11-04T09:11:23.000Z', 'yyyy-MM-dd HH:mm:ss');
     */
    ns.Date_Format = function(datestr, fmt)  { 
        var datestr = datestr.replace(/(\d{4})-(\d{2})-(\d{2})T(.*)?\.(.*)/, "$1/$2/$3 $4") + ' GMT';
        var theDate = new Date(datestr);

        var o = {   
            "M+" : theDate.getMonth()+1,                 //月份   
            "d+" : theDate.getDate(),                    //日   
            "h+" : theDate.getHours()%12 == 0 ? 12 : theDate.getHours()%12, //12小时       
            "H+" : theDate.getHours(),                   //24小时    
            "m+" : theDate.getMinutes(),                 //分   
            "s+" : theDate.getSeconds(),                 //秒   
            "q+" : Math.floor((theDate.getMonth()+3)/3), //季度   
            "S"  : theDate.getMilliseconds()             //毫秒   
        };   
        if (/(y+)/.test(fmt))    
            fmt = fmt.replace(RegExp.$1, (theDate.getFullYear()+"").substr(4 - RegExp.$1.length));   
        for (var k in o)   
            if (new RegExp("("+ k +")").test(fmt))   
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
        return fmt;   
    }
    
    /*
        根据登录或者没登陆执行不同的操作
        @param function 如果是房产用户的话执行回调
        @param function 如果是资金用户执行回调
        @param function 如果是未登录用户执行的回调
     */
     // 取出来的数据放到这个字段里，以后直接调用
     ns.dataTmp = '';
     ns.ifLogExecute = function(real_cb,manager_cb,unLog_cb) {
        var userId = this.getCookie('userId');
        var self = this;
        if(userId){
            this.ajax('get','/user/'+userId,'')
            .then(function(data){
                self.dataTmp = data;
                if (data.type==1) {
                    real_cb(data);
                }else{
                    manager_cb(data);
                };
            })
        }else{
            if (unLog_cb) {
                unLog_cb();
            };
            
        }
     }

     /**
      * 房产类型中文
      * 房产类型 1住宅 2办公 3商铺 4小产权房 5厂房
      */
     ns.RealestateType = function(type){
        var typeCn= '';
        switch(type){
            case 1:
                typeCn = '住宅';
                break;
            case 2:
                typeCn = '办公';
                break;
            case 3:
                typeCn = '商铺';
                break;
            case 4:
                typeCn = '小产权房';
                break;
            case 5:
                typeCn = '厂房';
                break; 
            default:
                typeCn = '****'
        }
        return typeCn;
     };

     /**
      * 房产需求状态中文
      * 需求状态 -1无效 1申请中 2已发布 3对接成功 已关闭
      */
     ns.RealestateNeedStatus = function(type){
        if(type === 3){
            return '<span style="color:#23b107;">'
            + nsTools.RealestateNeedStatusValue(type) +'</span>';
        }else{
            return nsTools.RealestateNeedStatusValue(type);
        }
     };

    /**
     * 房产需求状态
     * @param {[type]} type [description]
     */
    ns.RealestateNeedStatusValue = function(type){
        var typeCn= '';
        switch(type){
            case -1:
                typeCn = '信息无效';
                break;
            case 1:
                typeCn = '申请中';
                break;
            case 2:
                typeCn = '已发布';
                break;
            case 3:
                typeCn = '对接成功';
                break;
            case 4:
                typeCn = '已关闭';
                break; 
        }
        return typeCn;
     };


     ns.getApplyStatus = function(status){
        switch(status){
            case -1:
                return '对接失败';
            case 1:
                return '申请中';
            case 2:
                return '对接成功';
            default:
                return '';
        }
     };


     /**
      * 房产需求类型中文
      * 需求类型 1房抵贷 2以房理财 3以房买房 4以房教育 5以房移民
      */
     ns.RealestateNeedType = function(type){
        var needTypeCn= '';
        switch(type){
            case 1:
                needTypeCn = '房抵贷';
                break;
            case 2:
                needTypeCn = '以房理财';
                break;
            case 3:
                needTypeCn = '以房买房';
                break;
            case 4:
                needTypeCn = '以房教育';
                break;
            case 5:
                needTypeCn = '以房移民';
                break; 
            default:
                needTypeCn = '****';
        }
        return needTypeCn;
     };

    /**
     * 房产数目中文
     * 
     */
    ns.RealestateNum = function(num){
        var RealestateNumCn= '';
        switch(num){
            case 1:
                RealestateNumCn = '仅一套房';
                break;
            case 2:
                RealestateNumCn = '两套房';
                break;
            case 3:
                RealestateNumCn = '三套房';
                break;
            case 4:
                RealestateNumCn = '四套房';
                break;
            case 5:
                RealestateNumCn = '五套房';
                break; 
            default:
                RealestateNumCn = '****';
        }
        return RealestateNumCn;
     };

    /**
    * 机构类型 1四大国有银行 2股份制银行 3地方性银行 4小贷公司 5投资机构(线下P2P) 6典当行
    */
    ns.getOrgType = function(num){
        switch(num){
            case 1:
                return '四大国有银行'
            case 2:
                return '股份制银行'
            case 3:
                return '地方性银行';
            case 4:
                return '小贷公司';
            case 5:
                return '投资机构(线下P2P)';
            case 6:
                return '典当行';
            default:
                return '';
        }
    };

    /**
    * 贷款期限
    */
    ns.getDebtDuration = function(num){
        switch(parseInt(num)){
            case 1:
                return '3个月';
            case 2: 
                return '6个月';
            case 3:
                return '1年';
            case 4:
                return '2年';
            case 5:
                return '3年';
            case 6:
                return '5年';
            case 7:
                return '10年';
            case 8:
                return '10年以上';
        }
    }

    /**
    * 解析产品/机构审核状态
    */
    ns.getProductStatus = function(num){
        switch(num){
            case -3:
                return '认证失败'
            case -2:
                return '已停用';
            case -1:
                return '待认证';
            case 1:
                return '认证成功';
            default:
                return '';
        }
    };

    //信贷员状态
    ns.getManagerStatus = function(num){
        switch(num){
            case -2:
                return '认证失败';
            case -1:
                return '已停用';
            case 1:
                return '待认证';
            case 2:
                return '资料已提交';
            case 3:
                return '认证成功';
            default:
                return '';
        }
    }


    /**
     * 产品特点
     */
    ns.getProductFeatureCn = function(v,liebiao){
        if (v === '') return '';
        var FeatureCnObj = {
            1: '手续简单',
            2: '用途无要求',
            3: '无征信要求',
            4: '无流水要求',
            5: '基准利率可款',
            6: '无服务费',
            7: '3天放款',
            8: '7天放款',
            9: '抵押率达90%',
            10: '抵押率达70%'
        };
        //1手续简单  2用途无要求 3无征信要求 4无流水要求 5基准利率可放款 6无服务费 73天放款 87天放款 9抵押利率可达90% 10抵押利率可达70%
        if (liebiao) {
            var str='';
            var arr = v.split(',');
            for (var i=0; i<arr.length; i++){
                if (arr[i])
                str +=  FeatureCnObj[arr[i]]+','
            }
            return str;
        }else{
            var str = '<ul>';
            var arr = v.split(',');
            for (var i=0; i<arr.length; i++){
                if (arr[i])
                str += '<li>' + FeatureCnObj[arr[i]] + '</li>';
            }
            str += '</ul>';
            return str; 
        };
        
    };

    ns.getProductFeatureImg =function(v,no_text) {
        var FeatureCnObj = {
            1: '手续简单',
            2: '用途无要求',
            3: '无征信要求',
            4: '无流水要求',
            5: '基准利率可款',
            6: '无服务费',
            7: '3天放款',
            8: '7天放款',
            9: '抵押率达90%',
            10: '抵押率达70%'
        };
        var a = v.split(',');
        var str = '';
        if (no_text) {
            for (var i = 0; i < a.length; i++) {
                if (a[i])
                str += "<li class='Feature_list'><img src='/images/product_feature_"+ a[i] +".png'/>"+'</li>';
            }
        }else{
            for (var i = 0; i < a.length; i++) {
                if (a[i])
                str += "<li class='Feature_list'><img src='/images/product_feature_"+ a[i] +".png'/>"+ FeatureCnObj[a[i]] + '</li>';
            }
        }
        
        return str;
    };

    /**
     * 信贷经理个人特质
     */
    ns.getPersonFeatureCn = function(v){
        if (v === '') return '';
        var FeatureCnObj = {
            1: '10分钟内对接',
            2: '2小时上门服务',
            3: '专业处理疑难杂症',
            4: '流程简便',
            5: '免费咨询',
            6: '免费评估',
            7: '全方位解决方案',
            8: '5年以上经验',
            9: '10年以上经验',
            10: '拥有本地户口',
            11: '公司资金雄厚',
            12: '自有资金放款',
            13: '银行资金放款',
        };

        var str = '';
        var arr = v.split(',');
        for (var i = 0; i < arr.length; i++) {
            if (arr[i])
                str += ' ' + FeatureCnObj[arr[i]] + ' ';
        }      

        return str;
    };

    ns.getPersonFeatureImg =function(v) {
        if (!v) return '';
        var FeatureCnObj = {
            1: '10分钟内对接',
            2: '2小时上门服务',
            3: '专业处理疑难杂症',
            4: '流程简便',
            5: '免费咨询',
            6: '免费评估',
            7: '全方位解决方案',
            8: '5年以上经验',
            9: '10年以上经验',
            10: '拥有本地户口',
            11: '公司资金雄厚',
            12: '自有资金放款',
            13: '银行资金放款',
        };
        var a = v.split(',');
        var str = '';
        for (var i = 0; i < a.length; i++) {
            str += "<li><img src='/images/person_feature_"+ a[i] +".png'/>"+ FeatureCnObj[a[i]] + '</li>';
        }
        return str;
    };

    ns.materialCredit = function(v) {
        if (v===1) {
            return "<span class='mar_r_10'><img src='/images/credit.png'>征信</span>";
        }else{
            return '';
        }
    };

    ns.materialPurpose = function(v) {
        if (v===1) {
            return "<span class='mar_r_10'><img src='/images/purpose.png'>用途</span>";
        }else{
            return '';
        }
    };

    ns.materialStream = function(v) {
        if (v===1) {
            return "<span class='mar_r_10'><img src='/images/stream.png'>流水</span>";
        }else{
            return '';
        }
    };

    //获取文章中去除html标签后的内容
    ns.getHtmlContent = function(strHtml, nums){
        strHtml = $.trim(strHtml);
        strHtml = strHtml.replace(/&nbsp;/, '');
        var trimResult = strHtml.replace(/<[^>]+>/g,"").substr(0, 300);
        trimResult = trimResult.substr(0, nums);
        return  trimResult + '...';
    };



     /**
     * 初始化一个uploadify按钮
     * @config {Object}
     * {
        inputId: '#uploadify',
        token: 'c401e890-a9bd-11e4-ab09-897e527f744a',
        buttonText,
        height
        width
     }
     @onUploadSuccess {Function} function(file, data, response)
     */
     ns.uploadify = function(config, onUploadSuccess){
        if(!config.buttonText){
            config.buttonText = '上传图片';
        }

        $(config.inputId).uploadify({
            //指定swf文件
            'swf': '/plugin/uploadify/uploadify.swf',
            //后台处理的页面
            'uploader': apiUrl + '/upload_file?token=' + config.token,
            //按钮显示的文字
            'buttonText': config.buttonText,
            //显示的高度和宽度，默认 height 30；width 120
            'height': config.height,
            'width': config.width,
            //上传文件的类型  默认为所有文件    'All Files'  ;  '*.*'
            //在浏览窗口底部的文件类型下拉菜单中显示的文本
            'fileTypeDesc': 'Image Files',
            //允许上传的文件后缀
            'fileTypeExts': '*.gif; *.jpg; *.png',
            //发送给后台的其他参数通过formData指定
            'formData': { 
            },
            //上传文件页面中，你想要用来作为文件队列的元素的id, 默认为false  自动生成,  不带#
            //'queueID': 'fileQueue',
            //选择文件后自动上传
            'auto': true,
            //设置为true将允许多文件上传
            'multi': false,
            'onUploadSuccess': onUploadSuccess
        });
     };

     ns.uploadifyAdmin = function(config){
        if(!config.buttonText){
            config.buttonText = '上传图片';
        }

        var uploadConfig = {
            //form字段名
            'fileObjName': 'upfile',
            //指定swf文件
            'swf': '/plugin/uploadify/uploadify.swf',
            //后台处理的页面
            'uploader': apiUrl + '/admin/upload_file?atoken=' + nsTools.getCookie('atoken'),
            //按钮显示的文字
            'buttonText': config.buttonText,
            //显示的高度和宽度，默认 height 30；width 120
            'height': config.height,
            'width': config.width,
            //上传文件的类型  默认为所有文件    'All Files'  ;  '*.*'
            //在浏览窗口底部的文件类型下拉菜单中显示的文本
            'fileTypeDesc': 'Image Files',
            //允许上传的文件后缀
            'fileTypeExts': '*.gif; *.jpg; *.png',
            //发送给后台的其他参数通过formData指定
            'formData': { 
            },
            //上传文件页面中，你想要用来作为文件队列的元素的id, 默认为false  自动生成,  不带#
            //'queueID': 'fileQueue',
            //选择文件后自动上传
            'auto': true,
            //设置为true将允许多文件上传
            'multi': true,
            'uploadLimit': 5,
            'onUploadSuccess': config.onUploadSuccess
        };

        if(config.onDialogOpen){
            uploadConfig.onDialogOpen = config.onDialogOpen;
        }

        if(config.multi !== undefined){
            uploadConfig.multi = config.multi;
        }

        $(config.inputId).uploadify(uploadConfig);
     };

    /**
     * [createUploadInput description]
     * @param  {String} uploadify input的id
     * @param  {String} 显示图片的div class
     * @param  {String} 图片输入框id
     * @return undefined
     */
    ns.createUploadInput = function(inputId, showImgAreaClass, dataInputId){
        nsTools.uploadifyAdmin({
            inputId: inputId,
            height: 40,
            width: 100,
            onDialogOpen: function(){
                //清空图片显示区域
                $(showImgAreaClass).text('');
            },
            onUploadSuccess: function(file, data, response){
                data = JSON.parse(data);

                $(showImgAreaClass).append('<img src="' 
                    + nsTools.imgServer + data.imgurl 
                    +'" width="100" height="100" />');

                $(dataInputId).val(data.imgurl);
            }
        });
    }

     /*
        传入类名添加弹出层
      */
     ns.layer = function(domClass) {
        return $.layer({
            type: 1,
            shade: [0.5,'#000'],
            area: ['auto', 'auto'],
            title: false,
            border: [0],
            page: {dom : '.'+domClass},
            shift:'left',
            offset:['', '']
        });
     };

     // ns.isRealPublic = function(userId, yes_cb, no_cb) {
     //    this.ajax('')
     // } 
    

    /**
     * 城市 省份填充数据
     * @param tmplId Array
     * @param appendTo Object
     */
     ns.getProvince = function(tmplId, appendToHtml){
        this.ajax('get','/city/province', '')
        .then(function(data){
            if (tmplId instanceof Array)
            {
                for (var i in tmplId)
                {
                    element = tmplId[i];
                    $("#" + element).tmpl(data).appendTo(appendToHtml[element]);
                }
                /*tmplId.forEach(function(element){
                    $("#" + element).tmpl(data).appendTo(appendToHtml[element]);
                });*/
            }else{
                $("#" + tmplId).tmpl(data).appendTo(appendToHtml[tmplId]);
            }
        });
     };

    /**
     * 获取城市中文名称
     * @param {String} areaid 可以是一个逗号分割的字符串
     */
    ns.getAreaName = function (areaid, id, type, sign_type) 
    {
        if (areaid === '0' ) 
        {       
                $(sign_type+id).text('不限');
                return;
        }else if(areaid === '-1'){
                $(sign_type+id).text('全国');
        }else{
            if (areaid.indexOf(',') !== -1){
                var area_arr = areaid.split(',');
                var cnname= '';
                for (var i in  area_arr)
                {
                    if (area_arr[i] !== '')
                    {
                        this.ajax('get','/city/areaname', area_arr[i])
                        .then(function(data){
                            if (data.length === 0) 
                            {
                                return;
                            }
                            if (data[0].parentname !== 'undefined' && data[0].parentname !== null) 
                            {
                                cnname += data[0].parentname + data[0].areaName + ', ';
                            }else {
                                cnname +=  data[0].areaName + ', ';
                            }

                            if (type === 'edit')
                            {
                                $(sign_type+id).val(cnname.substring(0, cnname.lastIndexOf(',')));
                            }else{
                                $(sign_type+id).val(cnname.substring(0, cnname.lastIndexOf(',')));
                                $(sign_type+id).text(cnname.substring(0, cnname.lastIndexOf(',')));
                            }
                        });
                    }
                } 
            }else{
                var cnname = '';

                this.ajax('get','/city/areaname', areaid)
                .then(function(data){
                    if (data.length == 0) {
                        return;
                    }
                    
                    if (data[0].parentname !== null) 
                    {
                        cnname += data[0].parentname + '-' + data[0].areaName ;
                    }else {
                        cnname +=  data[0].areaName ;
                    }
                    
                    if (type === 'edit')
                    {
                        $(sign_type+id).val(cnname);
                    }else{
                        $(sign_type+id).text(cnname);
                        $(sign_type+id).val(cnname);
                    }
                });
            }
         }
    }

    //匹配手机号首尾，以类似“150****5597”的形式输出
    ns.hidePhone = function(phone){
        return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
    };
    /**
     * [autoPutCity 如果cookie里面存有城市信息，则将文字内容和城市编号填入当前页面]
     * @param  {[number]} submit_value [城市编号，一般用于数据提交和查询 如:1]
     * @param  {[string]} show_value   [显示的城市名称 如：北京]
     * @return {[null]}              [如果没有信息则将显示内容设置为全国]
     */
    ns.autoPutCity = function(submit_value,show_value) {
        if (this.getCookie('userArea')) {
            $(show_value).val(this.getCookie('userAreaName'));
            $(submit_value).val(this.getCookie('userArea'));
        }else{
            $(show_value).val('全国');
        };
        var self = this;
        $('.ip-input').on('iptrigger', function() {
            $(show_value).val(self.getCookie('userAreaName'));
            $(submit_value).val(self.getCookie('userArea'));
        })       
    }
    /**
     * [baidu_tongji 通过iframe添加百度统计代码
     * 
     * ]
     * @param  {[string]} url [要访问的url]
     * @return {[null]}     [没有返回值，直接插入iframe]
     */
    ns.baidu_tongji = function(url) {
        $('body').append('<iframe src="/'+url+' "style="display:none;"></iframe>');
    }
    /**
     * [sex 根据数据类型返回先生女士]
     * @param  {[number]} val [服务器返回数据1，2]
     * @return {[string]}     [1是先生，2是女士]
     */
    ns.sex = function(val) {
        if (val==1) {
            return '先生'
        }else{
            return '女士'
        };
    }
    /**
     * [getFinalCity 如果所在城市是直辖市的话，直接返回直辖市的名称，不返回下面的区域]
     * @param  {[string]} cityname [可能的格式：例1上海-虹口区 例2福建-厦门市]
     * @return {[返回城市]}          [如果是例1，返回上海 ，例2 返回厦门市]
     */
    ns.getFinalCity = function(cityname) {
        var isMunicipality = false;
        var localMore = cityname.indexOf('-');
        var local_city;
        if(/[北京|上海|天津|重庆]\-/.test(cityname))
        {
            isMunicipality = true;
        }
        if(/全国/.test(cityname)){
            return '中国';
        }
        if ( localMore != -1 && !isMunicipality) {
            local_city=cityname.slice(localMore+1);
        }else{
            local_city = cityname.substring(0,2);
        }
        
        return local_city;
    }
    /**
     * [giveStar 没有数值返回星星]
     * @param  {[string]} v [字符的格式]
     * @return {[string]}   [如果没有值，返回星星]
     */
    ns.giveStar = function(v) {
        if (v) {
            return v;
        }else{
            return '***';
        };
    }
    ns.layerStop = function(v,cb) {
        layer.alert(v,1,cb)
    }

    ns.ipToCity = function() {
        var self = this;
        if(!this.getCookie('userArea')) {
            function setcity(result){
                var cityName = result.name;
                if(/[北京|上海|天津|重庆]市/.test(cityName))
                {
                    cityName = cityName.slice(0, -1);
                }

                self.ajax('get','/city/onearea/'+cityName,'')
                .then(function(data) {
                    if (data.areaid) {
                        self.setCookie('userArea', data.areaid, 20);
                        self.setCookie('userAreaName', cityName, 20);
                        $('#citybtn_headercity').val(self.getCookie('userAreaName'));
                        $('input[name=city_input_headercity]').val(self.getCookie('userArea'));
                        $('.ip-input').trigger('iptrigger');
                    };
                });
            }
            var myCity = new BMap.LocalCity();
            myCity.get(setcity);
        }
    }
    
    ns.isZZheShanghai = function(id) {
        var zs = ['183','2','408','409','410','411',
            '412','413','414','415','416','417','418','419','420',
            '421','422','423','424','425'];
        for (var i = 0; i < zs.length; i++) {
            if(parseInt(id)===parseInt(zs[i])){
                return true;
            }
        }
        return false;
    }

    ns.pagination = function(id,totalPages,cb) {
        $('#'+id).twbsPagination({
            first: '首页',  
            prev: '前一页',  
            next: '下一页',  
            last: '尾页',  
            totalPages: totalPages,
            visiblePages: (function(){
                if (totalPages>6) {
                    return 6;
                }else{
                    return Math.floor(totalPages);
                }
            }()),
            version: '1.1',
            onPageClick: function (event, page) {
                cb(page);
            }
        });
    }

    return ns;
}());

function c(a) {
    console.log(a);
}

function alert_go(text){
    $.layer({
        shade:[0],
        title: '提示',
        dialog: {
            type: 1,
            msg: text
        },
        area: ['auto', 'auto'],
        btns: 1,
        btn: ['确定'],
    });
}

window.alert=alert_go;







