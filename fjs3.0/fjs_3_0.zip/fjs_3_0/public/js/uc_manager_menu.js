var nsUcManagerMenu = function() {
    var ns = {};

    ns.listener = function() {
        $('.uc_nav_list').find('li').hover(function() {
                $(this).addClass('uc_menu_on');
            },
            function() {
                $(this).removeClass('uc_menu_on');
                addMenuOn(location.pathname);
            }
        );

        $('.uc_nav_list').find('li').removeClass('uc_menu_on');

        function addMenuOn(pathname) {
            switch (pathname) {
                case '/uc/manager':
                    $('.manager').addClass('uc_menu_on');
                    break;

                case '/uc/manager/info':
                    $('.manager_info').addClass('uc_menu_on');
                    break;

                case '/uc/manager/auth':
                    $('.manager_auth').addClass('uc_menu_on');
                    break;
                case '/uc/manager/set_password':
                    $('.manager_password').addClass('uc_menu_on');
                    break;

                case '/uc/manager/product':
                    $('.manager_product').addClass('uc_menu_on');
                    break;

                case '/uc/manager/agentproduct':
                    $('.manager_agentproduct').addClass('uc_menu_on');
                    break;

                case '/uc/manager/case':
                    $('.manager_case').addClass('uc_menu_on');
                    break;

                case '/uc/manager/apply':
                    $('.manager_apply').addClass('uc_menu_on');
                    break;
            }
        }

        addMenuOn(location.pathname);

    }

    return ns;
}();

nsTools.addListener('nsUcManagerMenu', nsUcManagerMenu.listener);