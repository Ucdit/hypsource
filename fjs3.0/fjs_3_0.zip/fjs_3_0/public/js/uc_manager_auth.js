var nsUcManagerAuth = function() {
    var ns = {};

    ns.listener = function() {
        var token = nsTools.getCookie('token');
        
        //初始化上传插件
        var config = {
            idcard : {
                inputId: '#idcard_upload_btn',
                token: token,
                height: 30,
                width: 90,
                buttonText: '上传照片'
            },
            namecard : {
                inputId: '#namecard_upload_btn',
                token: token,
                height: 30,
                width: 90,
                buttonText: '上传照片'
            },
            skillcard : {
                inputId: '#skill_upload_btn',
                token: token,
                height: 30,
                width: 90,
                buttonText: '上传照片'
            }

        };

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            // c(data)
            //资金方
            if (data.id_card_img !== '' )
            {
                $('#idcard_img').attr("src", nsTools.imgServer + data.id_card_img);
            }            

            if (data.name_card_img !== '' )
            {
                $('#namecard_img').attr("src", nsTools.imgServer + data.name_card_img);
            }

            if (data.license_img !== '' )
            {
                $('#skill_img').attr("src", nsTools.imgServer + data.license_img);
            }


            uploadPhoto(config.idcard, '#idcard_img', 'idcard');
            uploadPhoto(config.namecard, '#namecard_img', 'namecard');
            uploadPhoto(config.skillcard, '#skill_img', 'skillcard');

            if (data.status === 1) {

            } else if (data.status === 2) {
                $('.status_1 img').attr("src", '/images/step1_gray.png');
                $('.status_2 img').attr("src", '/images/step2_blue.png');
                $('input[type="file"]').hide();
                $('.uploadify').hide();
                $('.auth_btn').show();
            } else if (data.status === 3) {
                $('.status_1 img').attr("src", '/images/step1_gray.png');
                $('.status_2 img').attr("src", '/images/step2_gray.png');
                $('.status_3 img').attr("src", '/images/step3_blue.png');
                $('input[type="file"]').hide();
                $('.uploadify').hide();
                $('.auth_btn').hide();
            }

            $('.auth_btn').click(function(){
                /*var id_card_img = $('#idcard_img').attr("src").replace(nsTools.imgServer, "");
                if (id_card_img === '/images/photo_hold.png') {
                    id_card_img = '';
                }

                var name_card_img = $('#namecard_img').attr("src").replace(nsTools.imgServer, "");
                if (name_card_img === '/images/photo_hold.png') {
                    name_card_img = '';
                }

                var license_img = $('#skill_img').attr("src").replace(nsTools.imgServer, "");
                if (license_img === '/images/photo_hold.png') {
                    license_img = '';
                }

                var u_data = {};
                u_data.id_card_img = id_card_img;
                u_data.name_card_img = name_card_img;
                u_data.license_img = license_img;*/
                var token = nsTools.getCookie('token');
                nsTools.ajax('put', '/user/applyauth/' + data.id, {token: token})
                .then(function(data) {
                    $.layer({
                        title: '提示',
                        time: 2,
                        dialog: {
                            type: 1,
                            msg: '申请认证成功'
                        },
                        area: ['310px', '130px'],
                        btns: 1,
                        btn: ['确定'],
                        end: function() {
                            location.reload();
                        }
                    });
                });
            });

        }, function() {
            //未登录
            return location.href = '/login';
        });

    }

    function uploadPhoto(config, targetDom, type){
        nsTools.uploadify(config, function(file, data, response) {
            var data = JSON.parse(data);
            var imgUrl = nsTools.imgServer + data.imgurl;

            var new_data = {};
            var msg = '';
            if (type === 'idcard') {
                new_data.id_card_img = data.imgurl;
                msg = '身份证上传成功';
            } else if (type === 'namecard') {
                new_data.name_card_img = data.imgurl;
                msg = '名片上传成功';
            } else if (type === 'skillcard') {
                new_data.license_img = data.imgurl; 
                msg = '从业资格证上传成功'
            }

            var userId = nsTools.getCookie('userId');
            nsTools.ajax('put', '/user/' + userId, new_data)
            .then(function(data) {

            });
            $(targetDom).attr('src', imgUrl);
        });
    }

    return ns;
}();

nsTools.addListener('nsUcManagerAuth', nsUcManagerAuth.listener);