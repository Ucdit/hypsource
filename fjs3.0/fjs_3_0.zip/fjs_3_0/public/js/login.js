var nsLog = (function() {
    var ns = {};
    ns.listener = function() {
        // 如果已经登录则跳转回首页
        nsTools.ifLogExecute(function(data){
            window.location.href="/"
        },function(){
            window.location.href="/"
        })
        // 房产用户短信验证码登录方式
        var log_sms_n = {
            phone : 'input_phone_sms_n',
            sms_code : 'input_sms_sms_n',
        };
        $('.js_sms_log_n').validate({
            // 验证规则及验证话术
            rules : RULE.login.nLog_sms_rule,
            messages : RULE.login.nLog_sms_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var log_sms_n_back = nsTools.fetchInput(log_sms_n);
                c(log_sms_n_back)
                nsTools.ajax('post','/sms_login',log_sms_n_back)
                .then(function(data) {
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.setCookie('userType',data.user.type);
                    nsTools.setCookie('userGender',data.user.gender);
                    nsTools.setCookie('userLastName',data.user.last_name);
                    location.href="/";
                })
            }
        });
        // 房产用户密码登录方式
        var log_putong_n = {
            phone : 'phone_putong_n',
            password : 'password_putong_n',
        };
        $('.js_putong_log_n').validate({
            // 验证规则及验证话术
            rules : RULE.login.nLog_putong_rule,
            messages : RULE.login.nLog_putong_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var log_putong_n_back = nsTools.fetchInput(log_putong_n);

                nsTools.ajax('post','/login',log_putong_n_back)
                .then(function(data) {
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.setCookie('userType',data.user.type);
                    nsTools.setCookie('userGender',data.user.gender);
                    nsTools.setCookie('userLastName',data.user.last_name);
                    location.href="/";
                })
            }
        });
        // 信贷用户短信验证码登录方式
        var log_sms_m = {
            phone : 'input_phone_sms_m',
            sms_code : 'input_sms_sms_m',
        };
        $('.js_sms_log_m').validate({
            // 验证规则及验证话术
            rules : RULE.login.mLog_sms_rule,
            messages : RULE.login.mLog_sms_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var log_sms_m_back = nsTools.fetchInput(log_sms_m);

                nsTools.ajax('post','/sms_login',log_sms_m_back)
                .then(function(data) {
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.setCookie('userType',data.user.type);
                    nsTools.setCookie('userGender',data.user.gender);
                    nsTools.setCookie('userLastName',data.user.last_name);
                    location.href="/";
                })
            }
        });
        // 资金用户密码登录方式
        var log_putong_m = {
            phone : 'phone_putong_m',
            password : 'password_putong_m',
        };
        $('.js_putong_log_m').validate({
            // 验证规则及验证话术
            rules : RULE.login.mLog_putong_rule,
            messages : RULE.login.mLog_putong_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var log_putong_m_back = nsTools.fetchInput(log_putong_m);

                nsTools.ajax('post','/login',log_putong_m_back)
                .then(function(data) {
                    nsTools.setCookie('userId',data.user.id);
                    nsTools.setCookie('userType',data.user.type);
                    nsTools.setCookie('userGender',data.user.gender);
                    nsTools.setCookie('userLastName',data.user.last_name);
                    location.href="/";
                })
            }
        });



        // 注册表单切换
        nsTools.tabChange('js_log_li','js_log_block','active');
        // 动态验证码和普通登录切换
        nsTools.tabChange('js_type_n_list','js_type_n_block');
        nsTools.tabChange('js_type_m_list','js_type_m_block');
        // 绑定发送发送验证码事件
        nsTools.sendSms('js_sendSms_n',$('.input_phone_sms_n'),2);
        nsTools.sendSms('js_sendSms_m',$('.input_phone_sms_m'),2);
        // 防止多次提交
        nsTools.oneClick('登录中','js_sms_n');
        nsTools.oneClick('登录中','js_putong_n');
        nsTools.oneClick('登录中','js_sms_m');
        nsTools.oneClick('登录中','js_putong_m');
        // 根据身份选择tab
        var roleType = window.location.search.slice(-1);
        if (roleType==2) {
           $('.js_log_li')[1].click();
        };


	}
    return ns;
}());
nsTools.addListener('nsLog',nsLog.listener);
