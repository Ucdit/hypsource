var nsRealestate_immigrant = (function() {
    var ns = {};
    ns.listener = function() {
        // 如果为true，则需要注册再发布
        var needRegister = true;
        // 根据登录状态改变表单
        nsTools.ifLogExecute(function(data) {
            auto_input(data);
        },function(data) {
            auto_input(data);
            $('.js_oneClick').on('click',function() {
                alert('资金方用户不能发布房产需求');
                return false;
            })
        })
        
        // 渲染新闻列表
        // nsTools.ajax('GET','/news/search','')
        // .then(function(data) {
        //     $('#news_wrap').tmpl(data.slice(0,3)).appendTo($('.news_wrap'));
        //     $('.news').eq(2).css('border','none')
        // })
        function auto_input(data) {
            // 填写表单手机号并禁用
            $('.input_phone').val(data.phone).prop('disabled',true)
            .css('background','#eee');
            // 填写表单姓名并禁用
            $('.input_last_name').val(data.last_name).prop('disabled',true)
            .css('background','#eee');
            needRegister = false;
            $('.submit_wrap div.horizontal').css('margin-top',34);
        }
        // 房产抵押贷验证
        var newUser = {
            phone : 'input_phone',
            last_name : 'input_last_name',
            type : 'input_user_type',
            sms_code : 'input_sms_code',
        },
        newRealestate = {
            city : 'input_city',
            name : 'input_name',
            worth : 'input_worth',
        },
        newNeed = {
            type : 'input_need_type',
            amount_money : 'input_amount_money',
        };
        $('.js_buy_form').validate({
            // 验证规则及验证话术
            rules : RULE.realestate_buy.buy_rule,
            messages : RULE.realestate_buy.buy_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var newUser_back = nsTools.fetchInput(newUser);
                var newRealestate_back = nsTools.fetchInput(newRealestate);
                var newNeed_back = nsTools.fetchInput(newNeed);
                /*
                    注册用户-》发布房产-》发布需求
                 */
                
                if (needRegister) {
                    nsTools.ajax('post','/user',newUser_back)
                    .then(function(data) {
                        c(data)
                        newRealestate_back.user_id = data.user.id;
                        newNeed_back.user_id = data.user.id;
                        return nsTools.ajax('post','/realestate',newRealestate_back);
                    })
                    .then(function(data) {
                        newNeed_back.realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/other_need',newNeed_back);
                    })
                    .then(function(data) {
                        nsTools.baidu_tongji('statistic_regandsub');
                        nsTools.layerStop('恭喜您发布成功，我们的顾问会通过4008102999电话联系您。',function(){
                            location.href="/";
                        })
                    })
                }else{
                    newRealestate_back.user_id = nsTools.dataTmp.id;
                    newNeed_back.user_id = nsTools.dataTmp.id;
                    nsTools.ajax('post','/realestate',newRealestate_back)
                    .then(function(data) {
                        newNeed_back.realestate_id = data.realestate_id;
                        c(newNeed_back)
                        return nsTools.ajax('post','/other_need',newNeed_back);
                    })
                    .then(function(data) {
                        nsTools.baidu_tongji('statistic_later_sub');
                        nsTools.layerStop('恭喜您发布成功，我们的顾问会通过4008102999电话联系您。',function(){
                            location.href="/";
                        })
                    })
                };
            }
        });

        // 成功案例轮播
        // $('.slider_wrap').bxSlider({
        //     auto: true,
        //     auto_controls: true,
        //     nextSelector : '.go_right',
        //     prevSelector : '.go_left',
        //     nextText : '&gt;',
        //     prevText : '&lt;'
        // });

        // 绑定发送发送验证码事件
        nsTools.sendSms('js_sendSms',$('.input_phone'));
        // 防止多次提交
        nsTools.oneClick('申请中','js_submit');

        // 如果有城市则填写城市
        nsTools.autoPutCity('#city_input_immigrantcity','#citybtn_immigrantcity');

        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'immigrantcity';  
        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;

        nsTools.getProvince(cityIndex_tmplId, appendTo);

        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });

        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });

        // 点击默认页面其余位置关闭城市选择
        $(document).click(function(e){
           var cityDiv_immigrantcity = $('.detail-location-picker_immigrantcity')[0];
           var target = e.target;
           var citybtn_immigrantcity = $('.btn')[0];

           if (cityDiv_immigrantcity !== target && !$.contains(cityDiv_immigrantcity, target) && citybtn_immigrantcity !== target) 
           {
              $('.detail-location-picker_immigrantcity').hide();
           }

        });

        /*城市选择相关操作的js  结束*/

        exampleFunc(immigrant_exam);
        $(".label_right").text('贷款金额')
        $(".interest").remove();

    }
    return ns;
}());
nsTools.addListener('nsRealestate_immigrant',nsRealestate_immigrant.listener);