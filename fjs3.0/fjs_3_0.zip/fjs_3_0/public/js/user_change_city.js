var nsHeaderUserChangeCity = function(){
    var ns = {};

    ns.listener = function(){
        //顶部city的类后缀
        var cityHeader = 'headercity';

        $('#change_curr_city').bind('click',function(){
            $('.detail-location-picker_headercity').toggle();
        })

        //省份赋值
        var cityheader_tmplId   = 'city-list_' + cityHeader;
        var cityheader_appendTo = '.regions-page1_' + cityHeader;
        var appendTo = {};
        appendTo[cityheader_tmplId] = cityheader_appendTo;
        nsTools.getProvince(cityheader_tmplId, appendTo);

        //
        $('.p_c_toggle_' + cityHeader + ' li').click(function(){
           $('#city_input_' + cityHeader).val('');
           if ($(this).index() === 0) {
              $('.regions-page2_' + cityHeader + ' li:gt(0)').remove();
              $('.p_c_toggle_' + cityHeader + ' li').addClass('current').not(this).remove();
              $('.regions-page1_' + cityHeader).show();   
           }
        });

        //根据cookie中城市的值填充当前显示数据
        var userArea = nsTools.getCookie('userArea');
        var userAreaName = nsTools.getCookie('userAreaName');
        if (userArea != '')
        {
            $('#citybtn_' + cityHeader).val(userAreaName);
            $('input[name="city_input_' + cityHeader + '"]').val(userArea);
        }

        // 选择完二级城市立刻刷新页面
        $('.regions-page2_' + cityHeader).on('click','a',function(){
            location.reload();
        })

        //点击城市文字也弹出城市选择框
        $('#citybtn_' + cityHeader).on('click',function(){
            $('#change_curr_city').click();
        })

    }
    return ns;
}();

nsTools.addListener('nsHeaderUserChangeCity', nsHeaderUserChangeCity.listener);
