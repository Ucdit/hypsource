var nsRealestate = function(){
    var ns = {};
    ns.listener = function() 
    {
        var token = nsTools.getCookie('token');


        nsTools.ifLogExecute(function(data) {
                $('.name').text('用户名: ' + data.last_name + data.title);
                $('.phone400').text('400绑定电话: 4008102999-' + data.phone400);
                $('.phone').text('手机号码:(' + nsTools.hidePhone(data.phone) + ')');
                $('.weixin').text('微信号 ' + nsTools.giveStar(data.weixin));
                $('.sex').text('性别 ' + nsTools.giveStar((data.gender==1)?'男':'女'));

                if (data.face_image && data.face_image !== '/images/face.png') {
                    $('.user_img').find('img').attr('src', nsTools.imgServer + data.face_image);
                }
            },
            function(data) {
                return location.href = '/uc/manager';
            },
            function() {
                return location.href = '/login';
            })
    };
       
    return ns;

}();

nsTools.addListener('nsRealestate',nsRealestate.listener);