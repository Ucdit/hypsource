var nsUcManagerProductAdd = function() {
    var ns = {};

    ns.listener = function() {
        var token = nsTools.getCookie('token');

        nsTools.ifLogExecute(function(data) {
            //房产方
            return location.href = '/uc/realestate';
        }, function(data) {
            //资金方

            //用于自动匹配的所有机构数据数组
            var lookupdata = [];
            nsTools.ajax('get', '/org/orglist', '').then(function(data){
                for(var i in data){
                    var orgdata = {};
                    orgdata.value = data[i].name + '.' + data[i].department;
                    orgdata.data = data[i].id;
                    if (data[i].Product)
                    orgdata.product_id = data[i].Product.id;
                    lookupdata.push(orgdata);
                }
            });

            //自动匹配
            $('#autocomplete').autocomplete({
                lookup: lookupdata,
                onSelect: function (suggestion) {
                    // c(suggestion.value.split('.')[0] + '|' + suggestion.data);
                    // $('input[name="org_name"]').val(suggestion.value.split('.')[0]);
                    $('input[name="org_department"]').val(suggestion.value.split('.')[1]);
                    var org_id = suggestion.data;
                    var product_id = 0;
                    if (suggestion.product_id)
                    {
                        product_id = suggestion.product_id;
                    }
                    $.layer({
                        shade: [0.5, '#000'],
                        area: ['auto','auto'],
                        dialog: {
                            msg: '您确定要发布[ ' + suggestion.value.split('.')[0] + ' ]的产品吗?',
                            btns: 2,                    
                            type: 4,
                            btn: ['确定','取消'],
                            yes: function(){
                                var type = parseInt($.url('?type', location.href)) || 1;
                                var rs = publishExistProduct(org_id, product_id, type);
                                $.layer({
                                    title: '提示',
                                    time: 2,
                                    dialog: {
                                        type: 1,
                                        msg: rs.message
                                    },
                                    area: ['auto', 'auto'],
                                    btns: 1,
                                    btn: ['确定'],
                                    end: function() {
                                        if (type == 1) {
                                            location.href = '/uc/manager/product';
                                        } else {
                                            location.href = '/uc/manager/agentproduct';
                                        }
                                    }
                                });
                            }, no: function(){
                                $('input[name="org_name"]').val('');
                                $('input[name="org_department"]').val('');
                            }
                        }
                    });
                    
                }
            });

            //第一步的下一步验证表单
            $('.next_step').click(function(){
                $('#add_product_step1').validate({
                    rules: {
                        org_type: {
                            required: true,
                            min: 1
                        },
                        org_name: {
                            required: true
                        },
                        org_department: {
                            required: true
                        },
                        short_name:{
                            required: true,
                            rangelength:[2,8]
                        },
                        lng:{
                            required: true
                        },
                        lat:{
                            required: true
                        },
                        city_productcity:{
                            required: true,
                            min: 1
                        },
                        org_address:{
                            required: true
                        },
                        org_telephone:{
                            required: true,
                            number: true
                        },
                        desc:{
                            required: true
                        },
                    },
                    messages: {
                        org_type: {
                            required: "请选择机构类型",
                            min: "请选择机构类型"
                        },
                        org_name: {
                            required: "请填写机构名称"
                        },
                        org_department: {
                            required: "请填写机构支行或分公司"
                        },
                        short_name: {
                            required: "请填写机构简称",
                            rangelength: "简称为2至8个字"
                        },
                        lng: {
                            required: "请填写机构经度"
                        },
                        lat: {
                            required: "请填写机构纬度"
                        },
                        city_productcity: {
                            required: "请选择所在城市",
                            min: "请选择所在城市"
                        },
                        org_address: {
                            required: "请填写机构详细地址",
                        },
                        org_telephone: {
                            required: "请填写机构电话",
                        },
                        desc: {
                            required: "请填写机构介绍",
                        }
                    },
                    submitHandler: function(form) {
                        $('.status_1 img').attr("src", '/images/step1_gray.png');
                        $('.status_2 img').attr("src", '/images/step2_blue.png');
                        $('.info_area_step1').slideUp();
                        $('.info_area_step2').slideDown();

                        //第二步的验证
                        validateStep2();

                    }
                });
                

            });

            $('.previous_step').click(function(){
                $('.status_1 img').attr("src", '/images/step1_blue.png');
                $('.status_2 img').attr("src", '/images/step2_gray.png');
                $('.info_area_step2').slideUp();
                $('.info_area_step1').slideDown();
            });

            //初始化上传插件
            var config = {
                inputId: '#img_upload_btn',
                token: token,
                height: 30,
                width: 90,
                buttonText: '上传照片'
            };

            uploadPhoto(config, '#manager_img');

            /*城市选择相关操作的js  开始*/
            //房产所在城市
            var cityHouse = 'productcity';  
            var cityTargetArea = 'targetAreacity';

            //省份赋值
            var cityIndex_tmplId   = 'city-list_' + cityHouse;
            var cityIndex_appendTo = '.regions-page1_' + cityHouse;

            var cityTargetArea_tmplId = 'city-list_' + cityTargetArea;
            var cityTargetArea_appendTo = '.regions-page1_' + cityTargetArea;

            var appendTo = {};
            appendTo[cityIndex_tmplId] = cityIndex_appendTo;
            appendTo[cityTargetArea_tmplId] = cityTargetArea_appendTo;

            //省份赋值
            nsTools.getProvince([cityIndex_tmplId, cityTargetArea_tmplId], appendTo);

            //城市选择的显示与隐藏
            $('#citybtn_' + cityHouse).click(function(){
                $('.detail-location-picker_' + cityHouse).toggle();
                $('input[name=address]').attr('disabled',false);
                $('#addressWarn').hide();
            });

            //业务地域城市选择 (多选)
            $('#citybtn_' + cityTargetArea).click(function(){
               $('.detail-location-picker_' + cityTargetArea).toggle();
            });

            $('.region-level-tabs li').click(function(){
                $('input[name=address]').removeAttr('disabled');
                if ($(this).index() === 0) {
                    $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                    $('.region-level-tabs li').addClass('current').not(this).remove();
                    $('.regions-page1_' + cityHouse).show();   
                }
            });

            //选择全部
            $('.allcity_' + cityHouse).click(function(){
                $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
                $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
                $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
                $('.close_' + cityHouse).click();
            });



            /*********服务区域多选控制 开始 ********/
            $('.p_c_toggle_' + cityTargetArea + ' li').click(function() {
                $("#manyprovinces_span").show();
                $('#city_input_' + cityTargetArea).val('');
                $("#manycitys_span").hide();
                if ($(this).index() === 0) {
                    $('.regions-page2_' + cityTargetArea + ' li').remove();
                    $('.p_c_toggle_' + cityTargetArea + ' li').addClass('current').not(this).remove();
                    $('.regions-page1_' + cityTargetArea).show();
                }
            });

            //选择多个省份的控制开关
            $('input[name="manyprovinces"]').click(function() {
                //开启省份多选模式
                if ($(this).prop("checked")) {
                    $('#city_input_' + cityTargetArea).val('');
                    $('#citybtn_' + cityTargetArea).val('请选择地区');
                    //设置省份模式标识
                    $('#province_type').val(1);
                    $('#city_type').val(0);
                    $('input[name="everycity"]').each(function() {
                        $(this).click(function() {
                            var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                            $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                            if ($(this).prop("checked")) {
                                if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                    $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                    $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                                }
                            } else {
                                if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                    $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));
                                    $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                                }
                            }
                        });
                    }).show();
                    $('.p_area').removeAttr("onclick");
                } else {
                    $('#citybtn_' + cityTargetArea).val('请选择地区');
                    $('#province_type').val(0);
                    $('#city_input_' + cityTargetArea).val('');
                    $('input[name="everycity"]').each(function() {
                        $(this).prop("checked", false);

                        $(this).siblings('a').attr("onclick", "getcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                    }).hide();
                }
            });

            //选择多个市的控制开关
            $('input[name="manycitys"]').click(function() {
                //设置省份为单选模式
                $('#province_type').val(0);
                $('#city_input_' + cityTargetArea).val('');
                //开启区县多选
                if ($(this).prop("checked")) {
                    //设置城市为多选模式标识
                    $('#city_type').val(1);
                    $('input[name="everycity_2"]').each(function() {
                        $(this).click(function() {
                            var city_input_TargetArea = $('#city_input_' + cityTargetArea).val();
                            $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace('请选择地区', ''));
                            if ($(this).prop("checked")) {
                                if (city_input_TargetArea.indexOf($(this).val() + ',') === -1) {
                                    $('#city_input_' + cityTargetArea).val(city_input_TargetArea + $(this).val() + ',');
                                    $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val() + $(this).siblings('a').attr('title') + ',');
                                }
                            } else {
                                if (city_input_TargetArea.indexOf($(this).val() + ',') !== -1) {
                                    $('#city_input_' + cityTargetArea).val($('#city_input_' + cityTargetArea).val().replace($(this).val() + ',', ''));

                                    $('#citybtn_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).val().replace($(this).siblings('a').attr('title') + ',', ''));
                                }
                            }
                        });
                    }).show();
                    $('.p_area_2').removeAttr("onclick");
                } else {
                    $('#citybtn_' + cityTargetArea).val($('.p_c_toggle_' + cityTargetArea + ' li:eq(0)').attr('title'));
                    //设置城市为单选模式
                    $('#city_type').val(0);
                    //置空所有选择
                    $('#city_input_' + cityTargetArea).val($('#citybtn_' + cityTargetArea).attr('data'));
                    $('input[name="everycity_2"]').each(function() {
                        $(this).prop("checked", false);

                        $(this).siblings('a').attr("onclick", "setcity(" + $(this).val() + ", '" + $(this).siblings('a').attr('title') + "', '_" + cityTargetArea + "', 'targetArea')");
                    }).hide();
                }
            });
            /*********服务区域多选控制 结束*****/
            
            /*城市选择相关操作的js  结束*/


            //产品特点最多选择三项
            $('input:checkbox[name="person_trait"]').click(function() {
                if ($('input:checkbox[name="person_trait"]:checked').length > 3) {
                    $(this).removeAttr("checked");
                    layer.msg('最多选择三项');
                }
            });


        }, function() {
            //未登录
            return location.href = '/login';
        });

    

    };

    function uploadPhoto(config, targetDom){
        nsTools.uploadify(config, function(file, data, response) {
            var data = JSON.parse(data);
            var imgUrl = nsTools.imgServer + data.imgurl;
            $(targetDom).attr('src', imgUrl);
        });
    }

    //发布我的信贷产品(已存在的产品)
    function publishExistProduct(org_id, product_id, type)
    {
        var productdata = {};
        var result = {message: '产品发布成功'};
        var userId = nsTools.getCookie('userId');
        productdata.user_id = userId;
        productdata.product_id = product_id;
        productdata.org_id = org_id;
        productdata.type = type;
        nsTools.ajax('post', '/managerproduct/add', productdata)
        .then(function(data) {
            
        });
        return result;
    }
    
    function validateStep2 (){
        //发布产品第二步
            $('#add_product_step2').validate({
                rules: {
                    product_name: {
                        required: true,
                        rangelength:[2,6]
                    },
                    amount_money_min: {
                        required: true,
                        number: true,
                        maxlength: 5
                    },
                    amount_money_max: {
                        required: true,
                        number: true,
                        maxlength: 5
                    },
                    interest_min: {
                        required: true,
                        number: true
                    },
                    interest_max: {
                        required: true,
                        number: true
                    },
                    debt_duration_min: {
                        required: true,
                        min:1
                    },
                    debt_duration_max: {
                        required: true,
                        min:1
                    },
                    age_limit: {
                        required: true,
                        number: true,
                        maxlength:2
                    },
                    promise_duration_min: {
                        required: true,
                        number: true
                    },
                    promise_duration_max: {
                        required: true,
                        number: true
                    },
                    targetArea:{
                        required: true
                    }
                },
                messages: {
                    product_name: {
                        required: "请填写产品名称",
                        rangelength: "产品名称2至6个字"
                    },
                    amount_money_min: {
                        required: "请填写贷款金额下限",
                        number: "请填写数字",
                        maxlength: "金额最多5位"
                    },
                    amount_money_max: {
                        required: "请填写贷款金额上限",
                        number: "请填写数字",
                        maxlength: "金额最多5位"
                    },
                    interest_min: {
                        required: "请填写年利率下限",
                        number: "请填写数字"
                    },
                    interest_max: {
                        required: "请填写年利率上限",
                        number: "请填写数字"
                    },
                    debt_duration_min: {
                        required: "选择贷款期限上限",
                        min: "选择贷款期限上限"
                    },
                    debt_duration_max: {
                        required: "请选择贷款期限下限",
                        min: "选择贷款期限下限"
                    },
                    age_limit:{
                        required: "请填写房龄",
                        number: "请填写数字",
                        maxlength: "年限不能超过两位数"
                    },
                    promise_duration_min: {
                        required: "请填写最少放款天数",
                        number: "请填写数字"
                    },
                    promise_duration_max: {
                        required: "请填写最多放款天数",
                        number: "请填写数字"
                    },
                    targetArea:{
                        required: "请选择服务区域"
                    }
                    
                    
                },
                submitHandler: function(form) {

                    if ($('input:checkbox[name="person_trait"]:checked').length !== 3) {
                        $.layer({
                            title: '提示',
                            time: 5,
                            dialog: {
                                type: 1,
                                msg: '请选择3项产品特点'
                            },
                            area: ['auto', 'auto'],
                            btns: 1,
                            btn: ['确定'],
                            end: function() {
                                return false;
                            }
                        });
                    } else {

                        //禁止提交按钮
                        $('.success_step').attr('disabled',"true").text('提交中...');
                        var userId = nsTools.getCookie('userId');
                        var type = parseInt($.url('?type', location.href)) || 1;

                        //生成机构信息
                        var odata = {};
                        odata.user_id = userId;
                        odata.type = $('select[name="org_type"]').val();
                        odata.name = $('input[name="org_name"]').val();
                        odata.short_name = $('input[name="short_name"]').val();
                        odata.department = $('input[name="org_department"]').val();
                        odata.lng = $('input[name="lng"]').val();
                        odata.lat = $('input[name="lat"]').val();
                        odata.province = $('#citybtn_productcity').attr('data').split('-')[0];
                        odata.city = $('#citybtn_productcity').attr('data').split('-')[1];
                        odata.logo = $('#manager_img').attr("src").replace(nsTools.imgServer, "");
                        odata.address = $('input[name="org_address"]').val();
                        odata.telephone = $('input[name="org_telephone"]').val();
                        odata.desc = $('textarea[name="desc"]').val();

                        nsTools.ajax('post', '/org', odata)
                        .then(function(data){
                            //
                            var pdata = {};

                            pdata.user_id = userId;
                            pdata.org_id = data.id;
                            pdata.type = type;//产品类型

                            pdata.name = $('input[name="product_name"]').val();
                            pdata.amount_money_min = $('input[name="amount_money_min"]').val();
                            pdata.amount_money_max = $('input[name="amount_money_max"]').val();
                            
                            pdata.interest_min = $('input[name="interest_min"]').val();
                            pdata.interest_max = $('input[name="interest_max"]').val();

                            pdata.debt_duration_min = $('select[name="debt_duration_min"]').val();
                            pdata.debt_duration_max = $('select[name="debt_duration_max"]').val();
                            
                            pdata.refund_xxhb = $('input:checkbox[name="refund_xxhb"]').prop("checked") ? 1 : 0;
                            pdata.refund_debx = $('input:checkbox[name="refund_debx"]').prop("checked") ? 1 : 0;
                            pdata.refund_debj = $('input:checkbox[name="refund_debj"]').prop("checked") ? 1 : 0;
                            
                            pdata.pledge_house = $('input:checkbox[name="realestate_house"]').prop("checked") ? 1 : -1;
                            pdata.pledge_office = $('input:checkbox[name="realestate_office"]').prop("checked") ? 1 : -1;
                            pdata.pledge_shop = $('input:checkbox[name="realestate_shop"]').prop("checked") ? 1 : -1;
                            pdata.pledge_small_property_house = $('input:checkbox[name="realestate_small"]').prop("checked") ? 1 : -1;
                            pdata.pledge_factory = $('input:checkbox[name="realestate_factory"]').prop("checked") ? 1 : -1;
                            
                            pdata.age_limit = $('input[name="age_limit"]').val();
                            pdata.only_one_house = $('select[name="only_one_house"]').val();
                            pdata.second_bet = $('select[name="second_bet"]').val();
                            
                            pdata.material_credit = $('input:checkbox[name="credit"]').prop("checked") ? 1 : -1;
                            pdata.material_stream = $('input:checkbox[name="stream"]').prop("checked") ? 1 : -1;
                            pdata.material_purpose = $('input:checkbox[name="purpose"]').prop("checked") ? 1 : -1;

                            pdata.promise_duration_min = $('input[name="promise_duration_min"]').val();
                            pdata.promise_duration_max = $('input[name="promise_duration_max"]').val();
                            
                            pdata.service_area = $('input[name="targetArea"]').val();

                            var product_feature = [];
                            $('input:checkbox[name="person_trait"]').each(function() {
                                if ($(this).prop("checked")) {
                                    if (product_feature.indexOf($(this).val()) === -1) {
                                        product_feature.push($(this).val());
                                    }
                                }
                            });

                            if (product_feature.length > 1) {
                                pdata.product_feature = product_feature.join(',');
                            }

                            nsTools.ajax('post', '/product/add', pdata).then(function(data){
                                var mpdata = {};
                                mpdata.user_id = userId;
                                mpdata.type = type;
                                mpdata.product_id = data.product_id;
                                mpdata.org_id = pdata.org_id;
                                nsTools.ajax('post', '/managerproduct/add', mpdata).then(function(data){
                                    $.layer({
                                        title: '提示',
                                        time: 2,
                                        dialog: {
                                            type: 1,
                                            msg: "发布成功"
                                        },
                                        area: ['auto', 'auto'],
                                        btns: 1,
                                        btn: ['确定'],
                                        end: function() {
                                            if (type == 1) {
                                                location.href = '/uc/manager/product';
                                            } else if (type == 2) {
                                                location.href = '/uc/manager/agentproduct';
                                            } else {
                                                location.href = '/uc/manager/product';
                                            }
                                        }
                                    });
                                });
                            });
                        });

                    }
                }
            });


    }

    return ns;
}();

nsTools.addListener('nsUcManagerProductAdd', nsUcManagerProductAdd.listener);