var nsRealestate_mortgage = (function() {
    var ns = {};
    ns.listener = function() {
        // 如果为true，则需要注册再发布
        var needRegister = true;
        // 根据登录状态改变表单
        nsTools.ifLogExecute(function(data) {
            auto_input(data);
        },function(data) {
            auto_input(data);
            $('.js_oneClick').on('click',function() {
                alert('资金方用户不能发布房产需求');
                return false;
            })
        })

        $('.js_search').on('click',function(){
            var amount_money = $('.js_amount').val();
            var time  = $('.js_time').val();
            var interest  = $('.js_interest').val();
            var url = '/search?amount_money='+amount_money+'&interest='+
                      interest+'&debt_duration='+time;
            window.location.href=url;
        })

        // 渲染新闻列表
        nsTools.ajax('GET','/news/search','')
        .then(function(data) {
            c(data)
            $('#news_wrap').tmpl(data.slice(0,2)).appendTo($('.news_wrap'));
            $('.news').eq(2).css('border','none')
        })

        // 渲染推荐产品
        nsTools.ajax('get','/hot_product','?type=1&limit=4')
        .then(function(data) {
            $('#info_wrap').tmpl(data).appendTo($('.info_wrap'));
        });
        function auto_input(data) {
            // 填写两个表单手机号并禁用
            $('.input_phone').val(data.phone).prop('disabled',true)
            .css('background','#eee');
            // 填写两个表单姓名并禁用
            $('.input_last_name').val(data.last_name).prop('disabled',true)
            .css('background','#eee');
            needRegister = false;
            $('.submit_wrap div.horizontal').css('margin-top',34);
        }
    	// 房产抵押贷验证
        var newUser = {
            phone : 'input_phone',
            last_name : 'input_last_name',
            type : 'input_user_type',
            sms_code : 'input_sms_code',
        },
        newRealestate = {
            city : 'input_city',
            name : 'input_name',
            worth : 'input_worth',
        },
        newNeed = {
            amount_money : 'input_amount_money',
            type : 'input_need_type',
        };

        var realestate_id;
        var need_id;
        var layer_More;
        $('.js_mortgage_form').validate({
            // 验证规则及验证话术
            rules : RULE.realestate_mortgage.mortgage_rule,
            messages : RULE.realestate_mortgage.mortgage_messages,
            // 成功处理
            submitHandler: function(form) {
                $('.js_oneClick').trigger('clickFade');
                // 获取相应表单值
                var newUser_back = nsTools.fetchInput(newUser);
                var newRealestate_back = nsTools.fetchInput(newRealestate);
                var newNeed_back = nsTools.fetchInput(newNeed);
                /*
                    注册用户-》发布房产-》发布需求
                 */
                if (needRegister) {
                    nsTools.ajax('post','/user',newUser_back)
                    .then(function(data) {
                        newRealestate_back.user_id = data.user.id;
                        newNeed_back.user_id = data.user.id;
                        return nsTools.ajax('post','/realestate',newRealestate_back);
                    },function(data){
                        nsTools.trans400(data,2,'电话已注册，请登录');
                    })
                    .then(function(data) {
                        newNeed_back.realestate_id = data.realestate_id;
                        realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/need',newNeed_back);
                    })
                    .then(function(data) {
                        nsTools.baidu_tongji('statistic_regandsub');
                        need_id = data.realestate_need_id;
                        layer_More = nsTools.layer('js_form_two');
                        update();
                    })
                }else{
                    newRealestate_back.user_id = nsTools.dataTmp.id;
                    newNeed_back.user_id = nsTools.dataTmp.id;
                    nsTools.ajax('post','/realestate',newRealestate_back)
                    .then(function(data) {
                        newNeed_back.realestate_id = data.realestate_id;
                        realestate_id = data.realestate_id;
                        return nsTools.ajax('post','/need',newNeed_back);
                    })
                    .then(function(data) {
                        need_id = data.realestate_need_id;
                        layer_More = nsTools.layer('js_form_two');
                        nsTools.baidu_tongji('statistic_later_sub');
                        update();
                    })
                };
                
                
            }
        });

        // 第二个表单更新房产信息和需求信息
        function update() {
            var need_up = {
                interest : 'input_interest',
                debt_duration : 'input_debt_duration'
            }
            var real_up = {
                type : 'input_type',
                house_num : 'input_house_num',
                builder : 'input_builder',
                age : 'input_age',
                is_mortgaged : 'input_is_mortgaged'
            }

            $('.js_form_more').validate({
                // 验证规则及验证话术
                rules : RULE.product_detail.product_rule,
                messages : RULE.product_detail.product_messages,
                // 成功处理
                submitHandler: function(form) {
                    $('.js_more').trigger('clickFade');
                    need_up_back = nsTools.fetchInput(need_up);
                    real_up_back = nsTools.fetchInput(real_up);
                    // 更新房产
                    nsTools.ajax('put','/realestate/'+realestate_id,real_up_back)
                    .then(function(data) {
                        return nsTools.ajax('put','/need/'+need_id,need_up_back)
                    })
                    .then(function(data){
                        layer.close(layer_More);
                        nsTools.layer('js_form_three');
                    })
                }
            });
        }

		// 成功案例轮播
		// $('.slider_wrap').bxSlider({
		// 	auto: true,
		// 	auto_controls: true,
		// 	nextSelector : '.go_right',
		// 	prevSelector : '.go_left',
  //           nextText : '&gt;',
  //           prevText : '&lt;'
		// });

		// 绑定发送发送验证码事件
        nsTools.sendSms('js_sendSms',$('.input_phone'));
        // 防止多次提交
        nsTools.oneClick('申请中','js_submit');
        
        // 防止多次提交
        nsTools.oneClick('申请中','js_more');

        // 如果有城市则填写城市
        nsTools.autoPutCity('#city_input_mortgagecity','#citybtn_mortgagecity');

        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'mortgagecity';  
        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;

        nsTools.getProvince(cityIndex_tmplId, appendTo);

        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });

        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });

        // 点击默认页面其余位置关闭城市选择
        $(document).click(function(e){
           var cityDiv_mortgagecity = $('.detail-location-picker_mortgagecity')[0];
           var target = e.target;
           var citybtn_mortgagecity = $('.btn')[0];

           if (cityDiv_mortgagecity !== target && !$.contains(cityDiv_mortgagecity, target) && citybtn_mortgagecity !== target) 
           {
              $('.detail-location-picker_mortgagecity').hide();
           }

        });

        /*城市选择相关操作的js  结束*/

   	}
    return ns;
}());
nsTools.addListener('nsRealestate_mortgage',nsRealestate_mortgage.listener);