var nsRealestate_map = (function() {
    var ns = {};
    ns.listener = function() {
        var pageId = 1;
        // 背景图片1
        var bc_1 = '/images/realestate_num.png';
        // 背景图片2
        var bc_2 = '/images/map_bc_c.png';

        var every_page = 10;
        // 选择筛选重新渲染
        $('select').change(function() {
            searchReal();
        });
        // 选择地图重新渲染
        $('.regions-page2_mapcity ').on('click','li',function(){
            searchReal();
        });
        var currentCity = nsTools.getCookie('userAreaName');
        var finalCity = nsTools.getFinalCity(currentCity);
        // 选择全国则刷新页面显示全部房产
        $('.regions-page1_mapcity').on('click','a[val=5000]',function(){
            nsTools.setCookie('userArea',5000);
            nsTools.setCookie('userAreaName','全国');
        });
        // 总共需要出现的分页
        var needpage;
        // 当前页数为1
        var currentPage = 1;
        /*分页事件*/
        $('.page_wrap li').on('click',function() {
            var page = $(this).text();
            searchReal(page);
            $(this).addClass('active').siblings().removeClass('active');
            $('.curent_page').text('').hide();
        });
        $('.nextpage').on('click',function() {
            if (currentPage>=4) {
              searchReal(currentPage+1);
              $('.page_wrap li').removeClass('active');
              $('.curent_page').text(currentPage+1).show();
            }else{
              $('.curent_page').text('').hide();
              $('.page_wrap li').eq(currentPage).trigger('click');
            }
        });
        /*分页结束*/
        function searchReal(click_page) {
            var real_type = $('#real_type').val();
            var mortgage_type = $('#mortgage_type').val();
            var real_num = $('#real_num').val();
            var city = $('#city_input_mapcity').val();
            city = nsArea.findAllcity(city);
            var cityValue = nsTools.getFinalCity($('#citybtn_mapcity').val());
            var submit_time = $('#submit_time').val();
            var loan_amount = $('#loan_amount').val();

            if (cityValue == '中国') {
              mp.centerAndZoom('中国',5);
            }else{
              mp.centerAndZoom(cityValue,12);
            }
            
            if ((typeof click_page)=='undefined') {
              click_page = 1;
            }
            var searchString = '?realestatetype='+real_type+'&is_mortgaged='+
                            mortgage_type+'&page='+click_page+
                            '&city='+city+'&created_at='+submit_time+'&amount_money='+loan_amount;

            // 清空左侧列表
            $('.realestate_list_wrap').html('');
            // 清空所有覆盖物
            mp.clearOverlays();
            // 开始渲染
            nsTools.ajax('get','/need/search',searchString)
            .then(function(data) {
                // 总页数
                needpage = Math.ceil(data.count/10);
                // 当前点击页数
                currentPage = Math.floor(click_page);
                
                // 如果页数大于5，则显示下一页
                if (needpage>5) {
                  $('.js_give_more').show();
                }
                // 如果页数不够就隐藏相应的分页
                // c(needpage)
                if(needpage==1){
                  $('.page_wrap li').eq(0).show().siblings().hide();
                  $('.js_give_more').hide();
                }else if(needpage==2){
                  $('.page_wrap li').show().eq(1).nextAll().hide();
                  $('.js_give_more').hide();
                }else if (needpage==3) {
                  $('.page_wrap li').show().eq(2).nextAll().hide();
                  $('.js_give_more').hide();
                }else if(needpage===0){
                  $('.page_wrap li').hide();
                  $('.js_give_more').hide();
                }else{
                  $('.page_wrap li').show();
                  $('.js_give_more').show();
                }
                // 渲染列表
                $('#realestate_list').tmpl(data.rows).appendTo('.realestate_list_wrap');
                // 共多少套房产
                $('.real_count').text(data.count);
                if (data.count===0) {
                  $('.realestate_list_wrap').html('<div class="has_no">根据筛选条件没有筛选出房产</div>');
                }else{

                }
                var myCompOverlay=[];
                var pointOb = [];
                var length = data.rows.length;
                for (var i = 0; i < length; i++) {
                    // 简化返回数据
                    var lng = data.rows[i].Realestate.lng;
                    var lat = data.rows[i].Realestate.lat;
                    var data_f = data.rows[i];
                    myCompOverlay[i] = new RealOverlay(new BMap.Point(lng,lat),data_f);
                    pointOb[i] = new BMap.Point(lng,lat);

                    mp.addOverlay(myCompOverlay[i]);
                    // 添加列表计数
                    $('.tag_num').eq(i).text(i+1);
                    // 添加地图标签计数
                    $('.tag_map').eq(i).text(i+1);

                    nsTools.getAreaName(data_f.Realestate.city, 'city_'+data_f.id, null, '.');

                }
                // 点击居中地图且显示信息框
                $('.map_list').on('click',function() {
                    var index=$(this).index();
                    myCompOverlay[index].show();
                    mp.centerAndZoom(pointOb[index],11);
                    $('.real_detail.map').hide().eq(index).show();
                });
                // 经过改变旁边列表的标签颜色和改变地图标签颜色
                $('.map_list').on('mouseover',function() {
                    var index=$(this).index();
                    $('.tag_num').eq(index).css('background-image',"url("+bc_2+")");
                    myCompOverlay[index].addBc();
                });
                // 离开恢复颜色
                $('.map_list').on('mouseout',function() {
                    var index=$(this).index();
                    $('.tag_num').eq(index).css('background-image',"url("+bc_1+")");
                    myCompOverlay[index].reMoBc();
                });

            });

        }

        
        // 百度地图API功能
        var mp = new BMap.Map("map_wrap");
        mp.centerAndZoom(finalCity);
        mp.enableScrollWheelZoom();

        // 覆盖物类重写
        function RealOverlay(point, data){
          this._point = point;
          this._data = data;
        }
        // 继承地图标签类
        RealOverlay.prototype = new BMap.Overlay();
        // 地图初始化最先执行
        RealOverlay.prototype.initialize = function(map){
          this._map = map;
          var infoContent = $('.text_get').html();
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = BMap.Overlay.getZIndex(this._point.lat);
          var overlayDom = $('.text_get').html();
          $(div).html(overlayDom);
          
          var _data = this._data;
          var real = _data.Realestate;
          var user = _data.User;
          $(div).find('.amount_real').text(nsTools.giveStar(this._data.amount_money)+'万');
          $(div).find('.name').text(user.last_name  + (user.gender === 1 ? '先生' : '女士'));
          // $(div).find('.city').text(real.city);
          $(div).find('.real_name').text(real.name);
          $(div).find('.time').text(nsTools.Date_Format(_data.created_at, 'yyyy-MM-dd'));
          $(div).find('.value').text(real.worth+'万');
          $(div).find('.interest').text(nsTools.giveStar(_data.interest)+'%');
          $(div).find('.views').text(_data.num_views);
          $(div).find('.real_brief').prop('src',nsTools.imgServer2+real.RealestateImgs[0].image);
          $(div).find('.lookup').prop('href','/realestate_detail?id='+_data.id);
          mp.getPanes().labelPane.appendChild(div);
          
          this.addEvent('click',function(){
              $(div).find('.real_detail').toggle();
          });

          return div;
        };
        // api必须重写的方法
        RealOverlay.prototype.draw = function(){
          var map = this._map;
          var pixel = map.pointToOverlayPixel(this._point);
          this._div.style.left = pixel.x + "px";
          this._div.style.top  = pixel.y - 30 + "px";
        };
        // 重写事件
        RealOverlay.prototype.addEvent = function(event,fun){
            this._div['on'+event] = fun;
        };
        // 显示详情框
        RealOverlay.prototype.show = function(){
            $(this._div).find('.real_detail').show();
        };
        // 添加黄色背景
        RealOverlay.prototype.addBc = function(){
            $(this._div).find('.tag_map').css('background-image',"url("+bc_2+")");
        };
        // 恢复原来背景
        RealOverlay.prototype.reMoBc = function(){
            $(this._div).find('.tag_map').css('background-image',"url("+bc_1+")");
        };

        // 如果有城市则填写城市
        nsTools.autoPutCity('#city_input_mapcity','#citybtn_mapcity');

        searchReal();

        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'mapcity';  
        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;

        nsTools.getProvince(cityIndex_tmplId, appendTo);

        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });

        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            //$('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            //$('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });

        // 点击默认页面其余位置关闭城市选择
        $(document).click(function(e){
           var cityDiv_mapcity = $('.detail-location-picker_mapcity')[0];
           var target = e.target;
           var citybtn_mapcity = $('.btn')[0];

           if (cityDiv_mapcity !== target && !$.contains(cityDiv_mapcity, target) && citybtn_mapcity !== target) 
           {
              $('.detail-location-picker_mapcity').hide();
           }

        });

        /*城市选择相关操作的js  结束*/
        

   	};
    return ns;
}());
nsTools.addListener('nsRealestate_map',nsRealestate_map.listener);



