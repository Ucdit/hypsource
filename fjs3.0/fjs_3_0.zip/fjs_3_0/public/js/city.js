 function getcity(areaid, areaName, ind, inputname, savetocookie, childids)
{  
   $('.p_c_toggle'+ind+' li').eq(0).text(areaName).attr({'val': areaid, 'title': areaName}).removeClass("current");
   $('#citybtn'+ ind).val(areaName);
   $('#citybtn'+ ind).attr('data', areaid);
   $('#city_input' + ind).val(areaid);
   
   if (inputname !== '')
   {
      $('input[name="' + inputname + '"]').val(areaid);
      $('#citybtn'+ind).val(areaName);
   }

   if (childids)
   {
      areaid = childids;
      $('input[name="' + inputname + '"]').val(areaid);
   }

   if ( areaid === '0') {
      $('.close_city').click();
      if (savetocookie)
      {
         nsTools.setCookie('userArea', 5000, 20);
         nsTools.setCookie('userAreaName', '全国', 20);
      }

      window.location.reload();
      return;
   }

   nsTools.ajax('get', '/city/areaid/' + areaid, '')
   .then(function(data){
      $('.regions-page1' + ind).hide();
      $('.p_c_toggle'+ ind).append('<li class="current" style="width: 33%" title="请选择">请选择</li>');
      $("#city-city"+ind).tmpl(data).appendTo('.regions-page2'+ ind);
   });

   $("#manyprovinces_span").hide();
   $("#manycitys_span").show();

   if (savetocookie)
   {
      nsTools.setCookie('userArea', areaid, 20);
      nsTools.setCookie('userAreaName', areaName, 20);
   }
}

function setcity(areaid, areaName, ind, inputname, savetocookie)
{
   $('.p_c_toggle'+ind+' li').eq(1).text(areaName);
   $('this').addClass('current');
   var cbtn = $('#citybtn'+ind).val();
   var cbtndata = $('#citybtn'+ind).attr('data');
   var strpos = cbtn.indexOf('-');
   if (cbtn.indexOf(areaName) === -1) {
      if (strpos > 0)
      {
         cbtn = cbtn.replace(/-.*$/, '');
         cbtndata = cbtndata.replace(/-.*$/, '');
      }
      $('#citybtn'+ind).val( cbtn + '-' + areaName);
      $('#citybtn'+ind).attr( 'data', cbtndata + '-' + areaid);

      if (inputname !== '')
      {
         $('input[name="' + inputname + '"]').val(areaid);
      }
   }
   $('.detail-location-picker' + ind).hide();

   if (savetocookie)
   {
      nsTools.setCookie('userArea', areaid, 20);
      nsTools.setCookie('userAreaName', cbtn + '-' + areaName, 20);
   }
}

//ESC键隐藏区域选择框
$(document).keydown(function(e){
   //ESC
   if (e.keyCode === 27)
   {
      $('.detail-location-picker').hide();
   }
});

// 点击默认页面其余位置关闭城市选择  头部
$(document).click(function(e){
  var cityDiv = $('.detail-location-picker');
  var target = e.target;
  var citybtn = $('.change_curr_city')[0];

  if (cityDiv[0] !== target && !$.contains(cityDiv[0], target) && citybtn !== target) 
  {
     $('.detail-location-picker_headercity').hide();
  }

});