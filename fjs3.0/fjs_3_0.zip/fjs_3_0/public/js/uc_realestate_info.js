var nsUcRealestate = function(){
    var ns = {};

    ns.listener = function(){

        nsTools.ifLogExecute(function(data) {
            $('input[name="name"]').val(data.last_name);
            $('input:radio[value="' + data.gender + '"]').attr("checked", true);
            $('input[name="phone"]').val(data.phone);
            $('input[name="phone400"]').val('4008102999-' + data.phone400);

            if (data.face_image && data.face_image !== '/images/face.png') {
                $('#manager_img').attr('src', nsTools.imgServer + data.face_image);
            }

            data.person_trait.split(',').forEach(function(i) {
                $('input:checkbox[name="person_trait"]').each(function() {
                    if ($(this).val() === i) {
                        $(this).attr("checked", "true");
                    }
                });
            });
            //初始化上传插件
            var config = {
                inputId: '#img_upload_btn',
                token: token,
                height: 30,
                width: 90,
                buttonText: '上传图片'
            };

            nsTools.uploadify(config, function(file, data, response) {
                var data = JSON.parse(data);
                var imgUrl = nsTools.imgServer + data.imgurl;

                var userId = nsTools.getCookie('userId');
                nsTools.ajax('put', '/user/' + userId, {'face_image' :  data.imgurl})
                .then(function(data) {
                    $.layer({
                        title: '提示',
                        time: 2,
                        dialog: {
                            type: 1,
                            msg: data.message
                        },
                        area: ['310px', '130px'],
                        btns: 1,
                        btn: ['确定'],
                        end: function() {
                            location.reload();
                        }
                    });
                });
                $('#manager_img').attr('src', imgUrl);
            });

            registerValidateEvent();

        }, function(data) {
            return location.href = '/uc/manager';
        }, function() {
            //未登录
            return location.href = '/login';
        });


    }

    function registerValidateEvent() {
        $('#user_form').validate({
            focusInvalid: true,
            rules: {
                name: {
                    required: true
                }
            },
            messages: {
                name: {
                    required: "请输入姓名"
                }
            },

            submitHandler: function(form) {
                var gender = $('input:radio[name="gender"]:checked').val();
                var name = $('input[name="name"]').val();
                var person_trait = [];
                $('input:checkbox[name="person_trait"]').each(function() {
                    if ($(this).prop("checked")) {
                        if (person_trait.indexOf($(this).val()) === -1) {
                            person_trait.push($(this).val());
                        }
                    }
                });

                var new_data = {};
                new_data.gender = gender;
                new_data.last_name = name;

                if (person_trait.length > 1) {
                    new_data.person_trait = person_trait.join(',');
                }

                var userId = nsTools.getCookie('userId');
                nsTools.ajax('put', '/user/' + userId, new_data)
                .then(function(data) {
                    $.layer({
                        title: '提示',
                        time: 2,
                        dialog: {
                            type: 1,
                            msg: data.message
                        },
                        area: ['310px', '130px'],
                        btns: 1,
                        btn: ['确定'],
                        end: function() {
                            location.reload();
                        }
                    });
                });
                
            }
        });
    }

    return ns;
}();


nsTools.addListener('nsUcRealestate',nsUcRealestate.listener);