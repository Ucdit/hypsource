var nsProduct_detail = (function() {
    var ns = {};
    ns.listener = function() {

    	// 从url中获得id
    	var id = parseInt($.url('?id', location.href)) || 1;
        // 渲染产品详情
        nsTools.ajax('get','/product',id)
        .then(function(data) {
            $('#institution_detail').tmpl(data).appendTo($('.institution_detail'));
            orgId = data.Org.id;
            // 渲染产品成功申请人
            // nsTools.ajax('get','/apply/user','?org_id='+orgId)
            // .then(function(data) {
            //     $('#succeed_persons').tmpl(data.slice(0,4)).appendTo($('.succeed_persons'));
            //     c(data)
            // });
            nsTools.getAreaName(data.service_area,'city_aa', null, '#');
            // 渲染本地信贷经理
            nsTools.ajax('get','/org',orgId+'/managers?type=1')
            .then(function(data) {
                if (data != '') {
                    $('#manager_local_detail').tmpl(data).appendTo($('.manager_local_detail'));
                }else{
                    $('#tmp_not_have').show();
                }
                
            });

            // 渲染合作信贷经理
            nsTools.ajax('get','/org',orgId+'/managers?type=2')
            .then(function(data) {
                if (data != '') {
                    $('#manager_coor_detail').tmpl(data).appendTo($('.hezuo_wrap'));
                }else{
                    $('#tmp_not_have_coor').show();
                };
                
            });
        });

        
        // 渲染推荐产品
        nsTools.ajax('get','/hot_product','?type=1&limit=4')
        .then(function(data) {
            $('#info_wrap').tmpl(data).appendTo($('.info_wrap'));
        });

        // 渲染推荐产品-房产抵押贷
        nsTools.ajax('GET','/product/search','')
        .then(function(data) {
            $('#xiangguan').tmpl(data.rows.slice(0,5)).appendTo($('.xiangguan'));
        })

        // 如果有城市则填写城市
        nsTools.autoPutCity('.input_city','#citybtn_applycity');

        // 防止多次提交
        nsTools.oneClick('申请中','js_submit_house');


        // 根据登录状态改变表单
        var im_manager = false;
        // 如果为true，则说明已经发布过房产，可以直接申请
        var having_need = false;
        var need_reg = true;
        nsTools.ifLogExecute(function(data) {
            // 填写两个表单手机号并禁用
            $('.input_phone').val(data.phone).prop('disabled',true)
            .css('background','#eee');
            // 填写两个表单姓名并禁用
            $('.input_last_name').val(data.last_name).prop('disabled',true)
            .css('background','#eee');
            nsTools.ajax('get','/having_need','?type=1&user_id='+data.id)
            .then(function(data){ 
                if (data.having_need==1) {
                    having_need = true;
                    need_id = data.need.id;
                }else{
                    need_reg = false;
                }
            })
        },function() {
            im_manager = true;
        })
        var userId;
        var manager_type;
        var newUser_back;
        var newRealestate_back;
        var newNeed_back;
        var realestate_id;
        var need_id;
        var layer_2;
        var orgId;
        // 点击申请按钮出现申请流程
        $('.product_wrap').on('click','.js_apply',function(e) {
            // 如果是信贷经理申请
            if (im_manager===true) {
                alert('信贷方不能发布申请');
                return false;
            };
            userId = $(this).attr('data-userId');
            orgId = $(this).attr('data-orgId');
            manager_type = $(this).data('type');
            // 如果用户已经登录，则不用注册直接发布
            if (having_need) {
                directSubmit();
                return false
            };
            // 注册了没有房产或者没有注册就执行注册流程
            var layer_1 = nsTools.layer('js_form_one');
            // 房产抵押贷验证
            var newUser = {
                phone : 'input_phone',
                last_name : 'input_last_name',
                type : 'input_user_type',
                sms_code : 'input_sms_code',
            },
            newRealestate = {
                city : 'input_city',
                name : 'input_name',
                worth : 'input_worth',
            },
            newNeed = {
                amount_money : 'input_amount_money',
                type : 'input_need_type',
            };
            
            $('.js_mortgage_form').validate({
                // 验证规则及验证话术
                rules : RULE.realestate_mortgage.mortgage_rule,
                messages : RULE.realestate_mortgage.mortgage_messages,
                // 成功处理
                submitHandler: function(form) {
                    if ($('#read_m').prop('checked')===false) {
                        alert('请同意协议');
                        return false;
                    };
                    $('.js_submit_house').trigger('clickFade');
                    // 获取相应表单值
                    newUser_back = nsTools.fetchInput(newUser);
                    newRealestate_back = nsTools.fetchInput(newRealestate);
                    newNeed_back = nsTools.fetchInput(newNeed);
                    /*
                        注册用户-》发布房产-》发布需求
                     */
                    if (need_reg) {
                        nsTools.ajax('post','/user',newUser_back)
                        .then(function(data) {
                            newRealestate_back.user_id = data.user.id;
                            newNeed_back.user_id = data.user.id;
                            return nsTools.ajax('post','/realestate',newRealestate_back);
                        })
                        .then(function(data) {
                            newNeed_back.realestate_id = data.realestate_id;
                            realestate_id = data.realestate_id;
                            return nsTools.ajax('post','/need',newNeed_back);
                        })
                        .then(function(data) {
                            need_id = data.realestate_need_id;
                            if(nsTools.isZZheShanghai(newRealestate_back.city)){
                                return nsTools.ajax('post','/apply',{
                                    type : 1,
                                    user_id : userId,
                                    need_id : data.realestate_need_id,
                                    manager_product_type : manager_type,
                                    org_id : orgId,
                                    is_inside:1
                                });
                            }else{
                                return nsTools.ajax('post','/apply',{
                                    type : 1,
                                    user_id : userId,
                                    need_id : data.realestate_need_id,
                                    manager_product_type : manager_type,
                                    org_id : orgId
                                });
                            }
                            
                        })
                        .then(function(data) {
                            c(data)
                            nsTools.baidu_tongji('statistic_regandsub.html');
                            // 关闭前一个弹出层
                            layer.close(layer_1);
                            layer_2 = nsTools.layer('js_form_two');
                            update();
                        })                        
                    }else{
                        newRealestate_back.user_id = nsTools.dataTmp.id;
                        newNeed_back.user_id = nsTools.dataTmp.id;
                        nsTools.ajax('post','/realestate',newRealestate_back)
                        .then(function(data) {
                            newNeed_back.realestate_id = data.realestate_id;
                            realestate_id = data.realestate_id;
                            return nsTools.ajax('post','/need',newNeed_back);
                        })
                        .then(function(data){
                            need_id = data.realestate_need_id;
                            if(nsTools.isZZheShanghai(newRealestate_back.city)){
                                return nsTools.ajax('post','/apply',{
                                    type : 1,
                                    user_id : userId,
                                    need_id : data.realestate_need_id,
                                    manager_product_type : manager_type,
                                    org_id : orgId,
                                    is_inside:1
                                });
                            }else{
                                return nsTools.ajax('post','/apply',{
                                    type : 1,
                                    user_id : userId,
                                    need_id : data.realestate_need_id,
                                    manager_product_type : manager_type,
                                    org_id : orgId
                                });
                            }
                            
                        })
                        .then(function(data) {
                            nsTools.baidu_tongji('statistic_later_sub.html');
                            // 关闭前一个弹出层
                            layer.close(layer_1);
                            layer_2 = nsTools.layer('js_form_two');
                            update();
                        })
                    };
                    
                }
            });
            
        })

        $('.js_later_add').on('click',function(){
            window.location.reload();
        })
        // 绑定发送发送验证码事件
        nsTools.sendSms('js_sendSms',$('.input_phone'));
        // 防止多次提交
        nsTools.oneClick('申请中','js_morething');
        var need_up_back;
        var real_up_back;
        // 第二个表单更新房产信息和需求信息
        function update() {
            var need_up = {
                interest : 'input_interest',
                debt_duration : 'input_debt_duration'
            }
            var real_up = {
                type : 'input_type',
                house_num : 'input_house_num',
                builder : 'input_builder',
                age : 'input_age',
                is_mortgaged : 'input_is_mortgaged'
            }

            $('.js_form_more').validate({
                // 验证规则及验证话术
                rules : RULE.product_detail.product_rule,
                messages : RULE.product_detail.product_messages,
                // 成功处理
                submitHandler: function(form) {
                    $('.js_morething').trigger('clickFade');
                    need_up_back = nsTools.fetchInput(need_up);
                    real_up_back = nsTools.fetchInput(real_up);
                    // 更新房产
                    nsTools.ajax('put','/realestate/'+realestate_id,real_up_back)
                    .then(function(data) {
                        return nsTools.ajax('put','/need/'+need_id,need_up_back)
                    })
                    .then(function(data){
                        layer.close(layer_2);
                        nsTools.layer('js_form_three');
                    })
                }
            });
        }
        // 不用注册直接发布
        var isZZSH = false;
        function directSubmit() {
            nsTools.ajax('get', '/user_need/'+ nsTools.dataTmp.id, '')
            .then(function(data){

                for (var i = 0; i < data.length; i++) {
                    if(nsTools.isZZheShanghai(data[i].Realestate.city)){
                        isZZSH = true;
                        break;
                    } 
                };
                if (isZZSH) {

                    
                    return nsTools.ajax('post','/apply',{
                        type : 1,
                        user_id : userId,
                        need_id : need_id,
                        manager_product_type : manager_type,
                        org_id : orgId,
                        is_inside:1
                    }).then(function(data){
                        alert('恭喜您已经提交成功！稍后房金所的客服会以4008-102-999电话联系您')
                    })
                }else{
                    nsTools.ajax('post','/apply',{
                        type : 1,
                        user_id : userId,
                        need_id : need_id,
                        manager_product_type : manager_type,
                        org_id : orgId,
                    })
                    .then(function(data) {
                        nsTools.layerStop("恭喜您申请成功，您申请的信息将以短信的方式通知该信贷经理。",function(){
                            location.reload();
                        });
                    })
                }
            })
            
        }

        /*城市选择相关操作的js  开始*/
        //房产所在城市
        var cityHouse = 'applycity';  
        //省份赋值
        var cityIndex_tmplId   = 'city-list_' + cityHouse;
        var cityIndex_appendTo = '.regions-page1_' + cityHouse;

        var appendTo = {};
        appendTo[cityIndex_tmplId] = cityIndex_appendTo;

        nsTools.getProvince(cityIndex_tmplId, appendTo);
        //城市选择的显示与隐藏
        $('#citybtn_' + cityHouse).click(function(){
            $('.detail-location-picker_' + cityHouse).toggle();
            $('input[name=address]').attr('disabled',false);
            $('#addressWarn').hide();
        });

        $('.region-level-tabs li').click(function(){
            $('input[name=address]').removeAttr('disabled');
            if ($(this).index() === 0) {
                $('.regions-page2_' + cityHouse + ' li:gt(0)').remove();
                $('.region-level-tabs li').addClass('current').not(this).remove();
                $('.regions-page1_' + cityHouse).show();   
            }
        });



        //选择全部
        $('.allcity_' + cityHouse).click(function(){
            $('#city_input_' + cityHouse).val($('#citybtn_' + cityHouse).attr('data').split('-')[0]);
            $('#citybtn_' + cityHouse).val($('#citybtn_' + cityHouse).attr('value').split('-')[0]);
            $('.p_c_toggle_' + cityHouse + ' li:eq(0)').click();
            $('.close_' + cityHouse).click();
        });
        /*城市选择相关操作的js  结束*/


    }
    return ns;
}());
nsTools.addListener('nsProduct_detail',nsProduct_detail.listener);

function transF(name,val) {
    if(transOb[name][val]) {
        return transOb[name][val];
    }else{
        return '';
    }
}
