var nsRealestateDetail = (function() {
    var ns = {};
    ns.listener = function() {
        
        //需求的id
        var id = parseInt($.url('?id', location.href)) || 1;

        
        var derectShowPhone = false;
        var phoneNum = '';
        var isApply = false;
        nsTools.ifLogExecute(function(data){
            nsTools.ajax('get','/can_view_phone','?user_id='+data.id+'&need_id='+id)
            .then(function(data){
                switch(data.code){
                    case 1 :
                        derectShowPhone = true;
                        phoneNum = data.phone;
                        showPhone(data.phone)
                        break;
                    default : 
                        phoneAlert('只有信贷经理，才有权限获取房产方的联系方式。');

                }
            })
        },function(data) {
            nsTools.ajax('get','/can_view_phone','?user_id='+data.id+'&need_id='+id)
            .then(function(data){
                switch(data.code){
                    case 1 :
                        showPhone(data.phone);
                        break;
                    case 2:
                        phoneAlert('只有信贷经理，才有权限获取房产方的联系方式。');
                        break;
                    case 3 :
                        phoneAlert('未通过认证的信贷经理不能查看房产的联系方式，请到个人中心申请认证。');
                        break;
                    // 需求方未申请信贷经理的产品
                    case 4 :
                        applyReal();
                        break;
                    case 5 :
                        phoneAlert('您不能直接查看本房产抵押贷需求，如需业务合作，请联系房金所客服。');
                        break;
                    case 6 :
                        phoneAlert('本房产抵押贷申请已经关闭，请尝试其他贷款申请。');
                        break;

                }
            })
        },function() {
            $('.realestate_info').on('click','.js_phone',function(){
                // alert('登录后才可以获取联系方式。');
                $.layer({
                    type: 1,
                    shade: [0.5,'#000'],
                    area: ['auto', 'auto'],
                    title: false,
                    border: [0],
                    page: {dom : '.reg'},
                    shift:'left',
                    offset:['', ''],
                    bgcolor: 'rgb(142, 139, 139)'
                });
            })
        })

        function showPhone(phone){
            $('.phone_number').hide();
            $('.already_show').show();
            $('.phone_text').text('4008102999-'+phone);
        }

        function phoneAlert(text) {
            $('.realestate_info').on('click','.js_phone',function(){
                alert(text);
            });
        }

        function applyReal() {
            $('.realestate_info').on('click','.js_phone',function(){
                if (isApply) {
                    alert('您已经获取过电话，请按照400电话联系房产方。');
                    return false;
                };
                nsTools.ajax('get','/view_phone','?user_id='+nsTools.dataTmp.id+'&need_id='+id)
                .then(function(data) {
                    switch(data.code) {
                        // 可以查看
                        case 1 : 
                            showPhone(data.phone)
                            alert('您已经成功获取电话。');
                            isApply = true;
                            break;
                        case 2 :
                            alert('只有发布过产品的信贷经理才能查看电话');
                            break;
                        case 3 :
                            alert('未通过认证的信贷经理不能查看房产的联系方式，请到个人中心申请认证。');
                            break;
                        // 超过查看次数
                        case 4 :
                            alert('本房产抵押贷申请正在处理中，请尝试其他贷款申请，如有需求请联系客服。');
                            break;
                        case 5 :
                            alert('本房产抵押贷处理正在申请中，请尝试其他贷款申请，如有需求请联系客服。');
                            break;
                        case 6 :
                            alert('您不能直接查看本房产抵押贷需求，如需业务合作，请联系房金所客服。');
                            break;
                        case 7 :
                            alert('本房产抵押贷申请已经对接成功，请尝试其他贷款申请。');
                            break;
                    }
                    
                })
            });
           
        }



        //获取需求信息
        nsTools.ajax('get','/need', id)
        .then(function(data) {
             $("#realestate-detail-info-tmp").tmpl(data).appendTo('.realestate_info');
             $("#realestate-detail-need-info-tmp").tmpl(data).appendTo('.need_info');
             // 百度地图API功能
             if (data.Realestate.lng) {
                var mp = new BMap.Map("map_info");
                 var pt = new BMap.Point(data.Realestate.lng,data.Realestate.lat);
                 mp.centerAndZoom(pt,12);
                 var myIcon = new BMap.Icon("/images/house_map.png", new BMap.Size(23,37));
                 var marker2 = new BMap.Marker(pt,{icon:myIcon});  // 创建标注
                 mp.addOverlay(marker2);
                 mp.enableScrollWheelZoom();
             }else{
                $('.map_info').hide();
                $('.news_wrap_all').show();
                // 渲染新闻列表
                nsTools.ajax('GET','/news/search','')
                .then(function(data) {
                    $('#news_wrap').tmpl(data.slice(0,3)).appendTo($('.news_wrap'));
                    $('.news').eq(2).css('border','none')
                })
             };
             

             nsTools.getAreaName(data.Realestate.city, 'rel_city', null, '.');

             //获取房产房价走势图
            if (data.Realestate.price_img) {
                $(".price_waver").attr('src',nsTools.imgServer2+data.Realestate.price_img.image);
                $('.direction_title').show();
            };
            data = data.Realestate.RealestateImgs;
            var realestateimg = [];

            for (var i = 0; i < data.length; i++) {
                realestateimg.push(data[i]);
            };

            if (realestateimg.length > 0) {
                $('.zoompic').html('<img src="'+ nsTools.imgServer2+realestateimg[0].image +'" width="354" height="300" alt=""/>');
            }

            $("#realestate-detail-photo-tmp").tmpl(realestateimg).appendTo('#thumbnail ul');

            //执行焦点图切换函数
            slideshow();
                
        });
        
    }
    return ns;
}());

nsTools.addListener('nsRealestateDetail',nsRealestateDetail.listener);