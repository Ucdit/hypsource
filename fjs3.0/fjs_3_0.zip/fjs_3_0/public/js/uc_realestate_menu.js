var nsUcRealestateMenu = function() {
    var ns = {};

    ns.listener = function() {
        $('.uc_nav_list').find('li').hover(function() {
                $(this).addClass('uc_menu_on');
            },
            function() {
                $(this).removeClass('uc_menu_on');
                addMenuOn(location.pathname);
            }
        );

        $('.uc_nav_list').find('li').removeClass('uc_menu_on');

        function addMenuOn(pathname) {
            switch (pathname) {
                case '/uc/realestate':
                    $('.realestate').addClass('uc_menu_on');
                    break;
                case '/uc/realestate/set_password':
                    $('.realestate_password').addClass('uc_menu_on');
                    break;
                case '/uc/realestate/my_need':
                    $('.realestate_need').addClass('uc_menu_on');
                    break;

            }
        }

        addMenuOn(location.pathname);

    }

    return ns;
}();

nsTools.addListener('nsUcRealestateMenu', nsUcRealestateMenu.listener);